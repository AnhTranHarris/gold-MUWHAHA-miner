"""Exploratory, not promotion-qualified: confidence/spacing quality-density frontier.
Fixed trained January Dukascopy HGB model, no refit; descriptive sweep over
thresholds and spacing, scoring observed real tick future markouts only.
"""
from pathlib import Path
import json,numpy as np
from joblib import load
from r00_directional_model import ROOT,frame,scores
from r00_signal_research import BASE
model=load(ROOT/'R00_HGB_signal_model.joblib')
levels=[0.50,0.52,0.54,0.56,0.58,0.60,0.62]
spacings=[5,10,15,20,30]
res=[]
for broker in ('dukascopy','coinexx'):
 for mo in ('01','02','06','07'):
  df=frame(broker,mo); sc,side=scores(model,df)
  t=df.utc_ms.to_numpy(dtype=np.int64); val=df.d30.to_numpy()
  good=df.recent.to_numpy()&(df.spread.to_numpy()<=1.)&np.isfinite(val)
  for th in levels:
   base=np.flatnonzero(good & (sc>=th))
   for gap in spacings:
    if gap==5:ids=base
    else:
     chosen=[];last=-2**62
     for j in base:
      if t[j]-last>=gap*1000:chosen.append(j);last=t[j]
     ids=np.array(chosen,dtype=np.int64)
    n=len(ids)
    res.append({'broker':broker,'source_month':mo,'threshold':th,'spacing_s':gap,'events':n,'r9_multiple':round(n/BASE[mo],3),'correct_direction_30s':round(float(np.mean(side[ids]*val[ids]>.1)),5) if n else None,'buy':int(np.sum(side[ids]>0)),'sell':int(np.sum(side[ids]<0))})
  print('Done',broker,mo,'max30',[(r['threshold'],r['events'],r['correct_direction_30s']) for r in res if r['broker']==broker and r['source_month']==mo and r['spacing_s']==30],flush=True)
  del df
(ROOT/'R00_quality_density_frontier.json').write_text(json.dumps({'exploratory':True,'not_predeclared_frozen_validation':True,'rows':res},indent=2))
