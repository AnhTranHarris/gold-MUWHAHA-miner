"""R00 read-only out-of-sample diagnostic, grouping/declustering signal counts.
No fills, positions, hypothetical exit, profit, or live performance is modeled.
"""
import gzip,json,hashlib,csv
from pathlib import Path
import numpy as np,pandas as pd
from joblib import load
from r00_directional_model import FS,ROOT,xmat,frame,scores
from r00_signal_research import BASE
model=load(ROOT/'R00_HGB_signal_model.joblib')
original=json.loads((ROOT/'R00_ML_direction_model.json').read_text())
th=original['confidence_threshold']
result=[];group_data=[]
for b in ['dukascopy','coinexx']:
 for mo in ['01','02','06','07']:
  df=frame(b,mo)
  prob,dir=scores(model,df)
  s=df.utc_ms.to_numpy(dtype='int64')
  d30=df.d30.to_numpy();d10=df.d10.to_numpy()
  mask=(prob>=th)&df.recent.to_numpy()&(df.spread.to_numpy()<=1.)&np.isfinite(d30)
  ix=np.flatnonzero(mask)
  dpred=dir[ix]; delta=d30[ix]
  selected=[]; since=-2**62
  for j in ix:
   if s[j]-since>=30000: selected.append(j); since=s[j]
  selected=np.asarray(selected,dtype=np.int64)
  raw=int(len(ix)); n=int(len(selected)); acc=float(np.mean(dir[selected]*d30[selected]>.1)) if n else None
  # Calculate canonical UTC hourly/calendar-day/ISO-week, not report-server conventions.
  selectedsets={'RAW_5S':ix,'DECLUSTER_30S':selected}
  for k,ids in selectedsets.items():
   if len(ids)==0:continue
   one=pd.DataFrame({'utc':pd.to_datetime(s[ids],unit='ms',utc=True),'dir':dir[ids], 'correct30':(dir[ids]*d30[ids]>.10).astype(int), 'correct10':(dir[ids]*d10[ids]>.10).astype(int),'has10':np.isfinite(d10[ids]).astype(int)})
   one['hour_utc']=one.utc.dt.strftime('%Y-%m-%dT%H:00:00Z')
   one['day_utc']=one.utc.dt.strftime('%Y-%m-%d')
   one['week_utc']=one.utc.dt.to_period('W-SUN').astype(str)
   for interval,col in [('hour','hour_utc'),('day','day_utc'),('week','week_utc')]:
    agg=one.groupby(col).agg(signals=('dir','size'),buy=('dir',lambda x:int((x>0).sum())),sell=('dir',lambda x:int((x<0).sum())),correct30=('correct30','sum'),correct10=('correct10','sum'),has10=('has10','sum')).reset_index()
    for row in agg.itertuples(index=False):group_data.append({'broker':b,'source_month':mo,'selection':k,'interval':interval,'utc_start':str(row[0]),'signals':int(row[1]),'buy_signals':int(row[2]),'sell_signals':int(row[3]),'correct30':int(row[4]),'correct10':int(row[5]),'with_10s_markout':int(row[6])})
  hours=np.unique(s[selected]//3600000).size
  result.append({'broker':b,'source_month':mo,'r9_synth_trades_month':BASE[mo],'raw_5s_signals':raw,'raw_5s_multiple':round(raw/BASE[mo],3),'unique_30s_opportunities':n,'unique_30s_multiple':round(n/BASE[mo],3),'directional30_unique':round(acc,5) if acc is not None else None,'buy30':int((dir[selected]>0).sum()),'sell30':int((dir[selected]<0).sum()),'active30_utc_hours':int(hours),'source_utc_first':str(pd.to_datetime(s[0],unit='ms',utc=True)),'source_utc_last':str(pd.to_datetime(s[-1],unit='ms',utc=True))})
  print(result[-1],flush=True)
  del df
out=ROOT/'R00_signal_interval_scorecard.csv.gz'
with gzip.open(out,'wt',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(group_data[0]));writer.writeheader();writer.writerows(group_data)
res={'method':'First REAL quote of populated 5-second UTC bucket; ML 30s fixed-horizon diagnostic. 30s dedup greedily keeps first signal 30,000ms after prior kept signal (both sides compete). NO trade execution. UTC hour/day/ISO week grouping. File-source-month != strict UTC calendar month especially Coinexx server shift. Raw market 5s buckets differ from R9 MT5 tester synthetic closed trades (aspirational benchmark only).','results':result,'grouped_rows':len(group_data),'grouped_file':out.name}
(ROOT/'R00_interval_audit.json').write_text(json.dumps(res,indent=2))
