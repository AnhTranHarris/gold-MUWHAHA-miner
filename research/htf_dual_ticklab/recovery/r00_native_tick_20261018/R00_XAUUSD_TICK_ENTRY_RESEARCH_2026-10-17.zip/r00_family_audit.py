"""Independent reconstructible signal family diagnostic on original REAL tick derived states.
Only earliest true quotes and completed candles; exploratory across all four
source months and both brokers, not economic fills or passed holdouts.
"""
import json,numpy as np
from pathlib import Path
from r00_signal_research import BASE,qualify,evalmask
from r00_directional_model import frame,ROOT
rows=[]
settings=[('impulse',.15,.2,1.0),('microflip',.15,.2,1.0),('vwap_reclaim',.15,.2,1.0),('fib_reaccel',.15,.2,1.0)]
for b in ['dukascopy','coinexx']:
 for mo in ['01','02','06','07']:
  df=frame(b,mo)
  for fam,min5,eff,spread in settings:
   for regime in ['adaptive','m5atr','h1agree','m1rsi']:
    mask,direct=qualify(df,min5=min5,eff=eff,spread=spread,regime=regime,family=fam)
    z30=evalmask(df,mask,direct,30,.1)
    z10=evalmask(df,mask,direct,10,.1)
    rows.append({'broker':b,'month':mo,'family':fam,'regime':regime,'signals30':z30['signals'],'times_r9':round(z30['signals']/BASE[mo],3),'directional30':z30['accuracy'],'directional10':z10['accuracy'],'long':z30.get('long',0),'short':z30.get('short',0)})
  print('Done',b,mo,[(r['family'],r['signals30'],r['directional30']) for r in rows if r['broker']==b and r['month']==mo and r['regime']=='adaptive'],flush=True)
(ROOT/'R00_rule_family_audit.json').write_text(json.dumps({'exploratory':True,'not_scored':True,'rows':rows},indent=2))
