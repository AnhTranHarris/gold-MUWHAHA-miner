"""R00/2: constructive multi-regime feature ablation, July month blocked.

Train Dukascopy Jan, Feb, June; freeze 4 feature-composition models;
calibrate signal confidence to >=1.6x R9 SYNTH June trade count using
June *feature* confidence only; then compare July Dukascopy + Coinexx.
No economic strategy/P&L; all label evaluations are explicit +30-second
midprice sign with abs(delta)>$0.10. Candidate decisions on tick arrivals.
"""
from pathlib import Path
import json,time,numpy as np,pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from r00_signal_research import BASE,evalmask
root=Path('/mnt/data/r00_data')
frames={mo:pd.read_pickle(root/f'R00_dukascopy_2026_{mo}_5s_events.pkl') for mo in ('01','02','06','07')}
coin=pd.read_pickle(root/'R00_coinexx_2026_07_5s_events.pkl')
base=['r5','r15','r30','r60','r300','eff15','spread']
reg=['r900','r3600','r14400','r43200','r86400','s15_dir','s30_dir',
     'm1_dir','m5_dir','m15_dir','m30_dir','h1_dir','h4_dir','h12_dir','d1_dir',
     'm1_atr','m5_atr','h1_atr','m1_rsi','m5_rsi','h1_rsi','w1_dir']
specs={'micro':base,'micro_regime':base+reg,
       'micro_vwap_fib':base+['quote_vwap_delta','fib_pos','m5_atr','m1_rsi'],
       'full':base+reg+['quote_vwap_delta','fib_pos','minute_of_day','s5_rsi','s15_rsi','s5_atr','s15_atr']}
rng=np.random.default_rng(20261017)
train=[]
for mo in ('01','02','06'):
 df=frames[mo]
 keep=np.flatnonzero(df.recent.to_numpy()&np.isfinite(df.d30.to_numpy())&(abs(df.d30.to_numpy())>.10))
 if len(keep)>55000:keep=np.sort(rng.choice(keep,55000,replace=False))
 train.append(df.iloc[keep]);print('train',mo,len(keep),flush=True)
train=pd.concat(train,ignore_index=True)
y=np.sign(train.d30.to_numpy()).astype('int8')
res=[]
for name,cols in specs.items():
 t=time.monotonic()
 mdl=HistGradientBoostingClassifier(max_iter=80,max_leaf_nodes=25,max_depth=6,
                    min_samples_leaf=220,learning_rate=.055,l2_regularization=5.,
                    early_stopping=False,random_state=20261017)
 mdl.fit(train[cols].to_numpy(dtype=np.float32),y)
 june=frames['06']
 p=mdl.predict_proba(june[cols].to_numpy(dtype=np.float32)).max(axis=1)
 eligible=june.recent.to_numpy()&(june.spread.to_numpy()<=1.)&np.isfinite(june.d30.to_numpy())
 target=int(np.ceil(BASE['06']*1.6))
 vals=np.sort(p[eligible]);th=float(vals[-min(target,len(vals))])
 print('trained',name,'th',round(th,6),'elapsed',round(time.monotonic()-t,2),flush=True)
 for b,mo,df in [('dukascopy','07',frames['07']),('coinexx','07',coin),('dukascopy','06',frames['06']),('dukascopy','02',frames['02'])]:
   preds=mdl.predict_proba(df[cols].to_numpy(dtype=np.float32))
   confidence=preds.max(axis=1)
   direct=np.where(preds[:,1]>=preds[:,0],1,-1)
   selected=(confidence>=th)&df.recent.to_numpy()&(df.spread.to_numpy()<=1.)
   z10=evalmask(df,selected,direct,10,.1)
   z30=evalmask(df,selected,direct,30,.1)
   r={'model':name,'broker':b,'month':mo,'signals':z30['signals'],
      'r9_multiple':round(z30['signals']/BASE[mo],3),'directional_10s':z10['accuracy'],
      'directional_30s':z30['accuracy'],'neutral_30s':z30['neutral_pct'],
      'long':z30['long'],'short':z30['short']}
   res.append(r);print(json.dumps(r),flush=True)
(root/'R00_multiregime_ablation.json').write_text(json.dumps({'design':'training Jan Feb June Duk; July blocked evaluation; no PnL',
                  'model_family':specs,'results':res},indent=2))
