# XAUUSD HTF R00 — Original Entry-Signal Research Receipt

**Date:** 2026-10-17. **Research classification:** EXPLORATORY; NOT_SCORED / NOT_INVESTOR_QUALIFIED / NO LIVE TRADING.

**User scope:** buy and sell OPPORTUNITY ENTRIES ONLY. No hold/exit/stop/profit/whole-account EA has been tested or manufactured by this R00 packet.

## Provenance and the exact parent originals (NOT substitutes or summaries)

- Anti-drift GOV-001: https://drive.google.com/file/d/1kS11NY0RRFaL0NQ-BxUc21u85Dej5VFq/view
- Investor INV-001: https://drive.google.com/file/d/1rSWeGBht_IvEWzS9gf5qIZprPIotuxvb/view
- Source exception SRC-002: https://drive.google.com/file/d/1qElhwjYLxunB1D_whIC6EJOSY8cHZ3qa/view
- Whole-system SYSTEM/1.1: https://docs.google.com/document/d/1f65dWnWa9AGGTKYoqQ_7rr28lQbx4EppQEGUUAMWW9U/edit
- Continuity/1.2 original: https://github.com/AnhTranHarris/gold-MUWHAHA-miner/blob/f9ca199d5c7627678b725c915e4c6eab279029da/research/htf_dual_ticklab/governance/CROSS_CUTTING_CONTINUITY_LAW_v1.2.md
- Report1: https://drive.google.com/file/d/19IS6aelL4Sj9m2hnevkGWqlNkcMhqaCp/view
- Report2: https://drive.google.com/file/d/1JJitSmvENPubAKD_f_HBxVKezgma8oDx/view
- Report3: https://drive.google.com/file/d/1nPlaRXsQctmw5TP3lMvl9-pqHEXwCM9c/view
- Report4: https://drive.google.com/file/d/1D5JxeJJTOaZPCkcqwlQ9jhJkh6hzRt9e/view
- Pinned R9 original code commit `8729a6345655a7b4ea31facc81982004ee2b8921`, blob `7eecb5f1947017a01ce85b2520725de54749e523`: https://github.com/AnhTranHarris/gold-MUWHAHA-miner/blob/8729a6345655a7b4ea31facc81982004ee2b8921/Experts/GoldMuwahahaMiner_R9_HybridGate.mq5
- Approved Python registry+clock baseline: https://github.com/AnhTranHarris/gold-MUWHAHA-miner/tree/ca4b58aec597174b6f6d18ab2f36cba6836e4f4c/research/htf_dual_ticklab/htf_ticklab
- PRIMARY Dukascopy originals https://drive.google.com/drive/folders/1lSCfO_awUKkbR4I6xDTy9orjIl0SrgIV ; PRIMARY Coinexx originals https://drive.google.com/drive/folders/1XzHug6HYQdSKIbKuGhBTOUHawAXynIb4

**All original reports and law documents were opened and read in this session; they remain complete at the links above. This new receipt does not summarize them.**

## Original tick input checksums

| Raw compressed basename | Exact source SHA-256 | Original tick rows | First UTC ms | Last UTC ms |
|---|---|---:|---:|---:|
| `XAUUSD_MT5_BROKER_2026_01_ticks_ALL.csv.gz` | `1307a75df5d635678de7691908600090a552f38543e0512187dcd7b37fbc66b8` | 7,699,274 | `1767308400480` | `1769810398953` |
| `XAUUSD_MT5_BROKER_2026_02_ticks_ALL.csv.gz` | `5de772aab4d15ebf18aa48850e847c98e2bcb639064790bbed9d87a598c3bf05` | 7,102,818 | `1769986825564` | `1772229598561` |
| `XAUUSD_MT5_BROKER_2026_06_ticks_ALL.csv.gz` | `3033ccb257d067aecc123f3791d9dddc5c95841b9bba167ff1ca0cf1589dc2b4` | 9,347,508 | `1780264801067` | `1782853198384` |
| `XAUUSD_MT5_BROKER_2026_07_ticks_ALL.csv.gz` | `d9d47d40abb33935414edfb5c11f0c518d8c9cc27221da182dab0bc49b0b708d` | 8,075,197 | `1782856800658` | `1785531598339` |
| `XAUUSD_DUKAS_2026_01_ticks.csv.gz` | `d2ebb9a8c19caad02c5d95d7c6504868722c286e1187d1dbad18098d8c5ec5c5` | 9,135,062 | `1767308400596` | `1769810391954` |
| `XAUUSD_DUKAS_2026_02_ticks.csv.gz` | `ed3b3545c990c88d78519594c17c8915b0f679adcb0a94920ba7524f1f6d5c5d` | 7,538,339 | `1769987186655` | `1772229599799` |
| `XAUUSD_DUKAS_2026_06_ticks.csv.gz` | `34686ce53ba992dfb83ea35d555b6a4947a9216635853857c8bf11ce70c00ae2` | 8,201,406 | `1780272000089` | `1782863999678` |
| `XAUUSD_DUKAS_2026_07_ticks.csv.gz` | `e171e8c2fb59f3f4147a6f845eb68e664fa9c0f4815caa33acdbb42cc2f768b7` | 7,415,841 | `1782864000330` | `1785531542882` |

**Original ticks total: 64,515,445.** Brokers were analyzed independently, never combined as one fictitious tape. Coinexx server-wall UTC shift: -120m Jan/Feb; -180m June/July.

## Decision-time causality and evaluation contract

Each decision occurs at the FIRST ACTUALLY OBSERVED quote in a populated epoch-anchored five-second bucket; no made-up bar quotes. Source attributes are current or previous ticks. HTF candle close/high/low/RSI/ATR are taken strictly from the PREVIOUS FULLY COMPLETED candle and joined by exact UTC interval. Cross-scale contexts: S5/S15/S30, M1/M5/M15/M30, H1/H4/H12/D1, prior completed W1 where available; preceding MONTHLY candle direction is deliberately unavailable (`NaN`) rather than invented due to missing contiguous past-month warmup. Rule families use Fibonacci M15 rolling extrema and a bid/ask quote-event-count mean called a VWAP PROXY, **not authentic exchange-volume VWAP**. No order-book volume supplied.

Training January Dukascopy, calibration February Dukascopy; June and July chronological replications (historical months are already exposed; do not call blind untouched OOS). Primary model HGB binary up/down with January balanced only as observed; fitting excludes neutral labels; scoring does not. Direction accuracy defined `direction*(future midpoint at first real quote >=30 seconds later - current midpoint)>$0.10`, future label only. No quote later than two seconds after the target look-ahead is accepted. This is a fixed-future **directional diagnostic**, not a trade exit or P&L. The label margin/horizon were researcher-assumed, NOT an investor-approved metric. Bid/ask side execution was not modeled.

## R9 reference and directly counted R00 observations

| Month | R9 SYNTH closed trades | +50% target | Dukas raw 5s | Dukas 30s spaced (calibrated classifier) | Dukas 30s spaced permissive | Dukas 20s spaced permissive | Coinexx 20s spaced permissive |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2026-01 | 27,980 | 41,970 | 76,301 | 19,775 | 47,394 | 67,032 | 74,350 |
| 2026-02 | 33,523 | 50,285 | 55,313 | 14,974 | 38,965 | 53,979 | 70,939 |
| 2026-06 | 31,801 | 47,702 | 100,472 | 23,231 | 52,819 | 75,196 | 78,203 |
| 2026-07 | 25,277 | 37,916 | 91,682 | 22,598 | 53,914 | 76,357 | 81,150 |

**Vital research distinction**: permissive 20-second-spaced candidates clear the raw COUNT goal in each month on each broker; they do **NOT** clear the ~90% directional-accuracy goal. At threshold 0.50, `max(p)` is trivially >=0.50 for a two-class model, so this is near-unfiltered market availability + cooldown capacity, **not a high-quality predictor**. Thirty-second-spaced calibrated candidates fall BELOW the +50% R9 target in every month. The first quoted raw count achievement does not certify independent successful entries.

## The original Jan-fit / Feb-calibrated binary predictor

| Broker | File-month | 5s raw signals | 30s direction hit rate (raw) | 30s-spaced signals | 30s direction hit rate (spaced) | 30s-spaced BUY/SELL |
|---|---|---:|---:|---:|---:|---|
| dukascopy | 2026-01 | 76,301 | 56.3% | 19,775 | 54.3% | 14,789 / 4,986 |
| dukascopy | 2026-02 | 55,313 | 49.1% | 14,974 | 48.6% | 10,480 / 4,494 |
| dukascopy | 2026-06 | 100,472 | 46.3% | 23,231 | 45.6% | 18,959 / 4,272 |
| dukascopy | 2026-07 | 91,682 | 46.7% | 22,598 | 46.1% | 17,837 / 4,761 |
| coinexx | 2026-01 | 95,275 | 55.7% | 23,321 | 54.0% | 17,483 / 5,838 |
| coinexx | 2026-02 | 95,760 | 49.2% | 22,263 | 48.8% | 15,980 / 6,283 |
| coinexx | 2026-06 | 111,502 | 46.3% | 24,757 | 45.8% | 20,490 / 4,267 |
| coinexx | 2026-07 | 110,215 | 45.8% | 25,877 | 45.4% | 20,662 / 5,215 |

**Ablations:** `R00_multiregime_ablation.json` documents four configurations: micro-only; micro+HTF regime; micro+quote-VWAP-proxy/Fibonacci; and fully combined. July Dukascopy showed 42,192 signals / 48.0% direction for the micro+VWAP-proxy/Fibonacci composition; the others scored ~48%. These are exploratory diagnostic classifier selections, not economic trades or a proven incremental paired full-system improvement.

**Hand-coded independently reconstructible families:** impulse, microflip, VWAP-proxy reclaim, Fibonacci-zone reacceleration, each with optional completed-M5 ATR, H1 alignment, or M1 RSI. Across 8 source-months all raw 30s direction scores are ~43–48%, see original 128-row `R00_rule_family_audit.json`; this says these configurations do not meet the defined direction goal, NOT that the whole mechanism space is impossible.

**Quality–density Pareto:** 7 confidence thresholds x 5 cooldown spacings x 8 tape-months = 280 diagnostic rows in `R00_quality_density_frontier.json`. Results after snooping must not be relabeled prospective out-of-sample.

## Scientific and governance caveats that affect what counts as a success

1. R9 monthly source counts are MT5 SYNTH TESTER closed trades by tester/calendar month, whereas data file-month has real UTC clock intervals and Coinexx crossing UTC month boundaries. Align exact active hours/UTC windows from R9 primary log before scored direct monthly/hourly/weekly ranking. This R00 volume check is a provisional aspirational benchmark and not a matched-window comparison.
2. First original MT5 H1 XLSX input confirmed its 272,352 trades, 69,609,920 SYNTH ticks, 0.01 lot, source inputs; full 1.61GB-XML orders/deals row extraction timed out, so exact R9 SYNTH matching UTC weekly/hourly data was not independently extracted in this run. New `R00_signal_interval_scorecard.csv.gz` DOES contain the candidate counts by UTC hour/day/ISO week.
3. The confidence sweeps and model variants were not preregistered in a frozen scored plan BEFORE execution: they are EXPLORATORY, NOT official governed experiment passes. The **next** scored plan should be frozen BEFORE execution.
4. The quote-count-weighted daily midpoint mean is NOT genuine traded-volume VWAP. Source files do not supply centralized exchange market volume. A quote-activity proxy can differ between brokers.
5. The labels are 10/30-second fixed-future midprice moves, not side-correct bid/ask realized fills. 90% accuracy remains UNVERIFIED. All P&L, holds, stops, exits, shared-account survival, drawdown and investor returns are NOT TESTED by this entry-only phase.
6. This local experiment did NOT modify, branch, or upload to GitHub/Drive; retain source files and their public locations. Artifacts must later be persistently backed up with verified digests to maintain continuity.

## Constructive follow-up candidates and sharper research question

**Research question**: On identical approved Coinexx and Dukascopy chronological bid/ask streams, which nonleaking combination of (a) volatility-scaled minute/5-second event rearming, (b) confirmed HTF liquidity sweeps and range-transition states, (c) M15/H1/H4 trend/ATR/RSI/Fibonacci structure, (d) session-aware spread/quote-density regimes, and (e) orthogonal pullback/reclaim versus continuation specialists can emit >=1.5x R9 SYNTH distinct BUY/SELL event opportunities in the same predefined UTC active hour/day/week/month windows **and simultaneously** achieve >=90% correctly labeled BUY/SELL directions on a frozen diagnostic price-horizon definition without being dominated by a single side? What minimal combination upgrades both hourly opportunity supply and conditional directional precision on June/July real-tick replications, and which ablation causes the improvement?

Proposed *next* work (not an assertion of measured edge): (A) create 3-state BUY/SELL/ABSTAIN regime-router with separate impulse continuation, microflip reversal, HTF sweep-reclaim and Fib pullback-confirmation experts, each with an explicit event reset and cooldown, (B) isolate absence-of-noise/predictability states and calibrate each broker/time window separately WITHOUT using future prices as current features, (C) directly classify 10s/30s directional precision with separate honest neutral and spread gates and side-balanced analysis, (D) freeze strict UTC-aligned R9 hourly baseline and rerun 4-month source-matched two-broker comparisons, (E) stop/discard overfit configurations but recycle failure insights into new falsifiable variants. No exits or profits will be scored until later EA integration.

**Community inspiration is NOT third-party trading data:**
- Open source MTF VWAP-style contexts and disclosed quote-volume caveats: https://www.tradingview.com/script/DvAlSsjj/
- Open source HTF sweep/reclaim with confirmed pivots/ATR thickness: https://www.tradingview.com/script/FG507Q8S-HTF-Liquidity-Sweep-Reclaim/
- Open source XAUUSD zone/displacement and session levels: https://www.tradingview.com/script/70dnQZ1K/
- Forum Asian high-low sweep plus London regime: https://www.forexfactory.com/thread/post/14806356
- Reconstructible Chinese code library ATR-buffer London breakout: https://www.mql5.com/zh/code/75586
- Japanese MQL5 multi-timeframe RSI panel engineering: https://www.mql5.com/ja/articles/357
Published third-party profit claims are NOT an input, label or scientific proof. Protected scripts and opaque products are not imported.

## Exact scripts and output files

- `r00_signal_research.py` SHA source hashes+feature extraction and deterministic 4-family rules.
- `r00_directional_model.py` January model, February threshold and monthly two-broker scores.
- `r00_multiregime_ablation.py` four feature-composition ablations.
- `r00_interval_audit.py` UTC hour/day/week and unique 30-second opportunity instrumentation.
- `r00_quality_density_frontier.py` 280-row volume/precision/cooldown frontier.
- `r00_family_audit.py` 128-row reconstructible multi-family sweep.
- All original small JSON results, per-source validation receipts, frozen model `.joblib`, and UTF-8 scorecard `.csv.gz` retained. Feature intermediates (`.pkl` ~75–95 MB each) and private approved raw source archives excluded from transfer ZIP by design; scripts reconstruct them only when all SHA-pinned source archives exist locally.

Next controlled experiment **planned** ID `R00-ENTRY-002` must be frozen prospectively; this work is `R00-ENTRY-001-EXPLORATORY` and must never be deceptively retro-promoted.
