"""R00/1 chronological multi-timeframe directional hypothesis model.

Fit only Dukascopy January 2026. Select event confidence threshold using
Dukascopy February only. Evaluate same frozen model/threshold on June and
July Dukascopy AND on independently recorded Coinexx January/February/
June/July. Different data tapes are NEVER pooled into fictitious prices.

Prediction target is signed +30 second FIRST AVAILABLE REAL QUOTE midprice
movement, +/- 0.10 price units. This is a DIRECTIONAL DIAGNOSTIC only,
not a trading exit, attainable P&L, win rate or broker executable result.
No future price enters features. Neutral moves count as non-directional.
"""
import hashlib, json, time
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from r00_signal_research import BASE, evalmask
ROOT=Path('/mnt/data/r00_data')
FS=['r5','r15','r30','r60','r300','r900','r3600','r14400','r43200','r86400',
    'eff15','spread','quote_vwap_delta','fib_pos','minute_of_day',
    's5_dir','s15_dir','s30_dir','m1_dir','m5_dir','m15_dir','m30_dir',
    'h1_dir','h4_dir','h12_dir','d1_dir','w1_dir',
    's5_atr','s15_atr','m1_atr','m5_atr','h1_atr',
    's5_rsi','s15_rsi','m1_rsi','m5_rsi','h1_rsi']

def frame(b,mo):return pd.read_pickle(ROOT/f'R00_{b}_2026_{mo}_5s_events.pkl')
def xmat(df):return df[FS].to_numpy(dtype=np.float32)
def scores(clf,df):
    ps=clf.predict_proba(xmat(df))
    assert list(clf.classes_)==[-1,1]
    return ps.max(axis=1),np.where(ps[:,1]>=ps[:,0],1,-1)
def eval_one(name,df,clf,threshold,limit_spread):
    confidence,direct=scores(clf,df)
    mask=(confidence>=threshold)&df.recent.to_numpy()&(df.spread.to_numpy()<=limit_spread)
    # The model is 30-second direction, but also evaluate 10-second fidelity.
    stats={}
    for h in [10,30]: stats[str(h)]=evalmask(df,mask,direct,h,.10)
    stats.update({'month':name,'threshold':round(float(threshold),6),
                  'actual_pct_R9':round(stats['30']['signals']/BASE[name.split('_')[1]]*100,1),
                  'observed_buckets':len(df),
                  'confidence_p95':round(float(np.quantile(confidence,.95)),4),
                  'evaluated_horizon_s':30})
    return stats

def main():
    t=time.monotonic()
    jan=frame('dukascopy','01')
    ok=jan.recent.to_numpy() & np.isfinite(jan.d30.to_numpy()) & (np.abs(jan.d30.to_numpy())>.10)
    inds=np.flatnonzero(ok)
    rng=np.random.default_rng(20261017)
    if len(inds)>150000: inds=np.sort(rng.choice(inds,150000,replace=False))
    x=xmat(jan.iloc[inds]);y=np.sign(jan.d30.to_numpy()[inds]).astype(np.int8)
    model=HistGradientBoostingClassifier(loss='log_loss',max_iter=65,max_leaf_nodes=20,
                          max_depth=5,min_samples_leaf=175,learning_rate=.055,
                          l2_regularization=5.0,early_stopping=False,random_state=20261017)
    print('FITTING',len(inds),'jan rows,',len(FS),'features',flush=True)
    model.fit(x,y);print('FIT_DONE',round(time.monotonic()-t,1),flush=True)
    feb=frame('dukascopy','02')
    sc,dr=scores(model,feb)
    mask=feb.recent.to_numpy()&(feb.spread.to_numpy()<=1.)
    # Meet Feb 1.5x R9 opportunity count with an additional fixed 10% buffer.
    n=int(np.ceil(BASE['02']*1.65))
    vals=np.sort(sc[mask & np.isfinite(feb.d30.to_numpy())])
    threshold=float(vals[max(0,len(vals)-min(n,len(vals)))])
    print('CALIBRATION Feb target',n,'confidence threshold',threshold,flush=True)
    results=[]
    for b in ['dukascopy','coinexx']:
      for m in ['01','02','06','07']:
        df=(jan if b=='dukascopy' and m=='01' else feb if b=='dukascopy' and m=='02' else frame(b,m))
        row=eval_one(f'{b}_{m}',df,model,threshold,1.)
        results.append(row)
        print(json.dumps(row),flush=True)
    out=ROOT/'R00_ML_direction_model.json'
    receipt={'model':'HGB binary fixed-horizon sign30 on REAL tick/multi-TF features',
       'training':'Dukascopy January 2026; neutral labels abs(move)<=0.10 excluded from fitting only',
       'calibration':'Dukascopy February 2026, 1.65x R9 target before transfer',
       'validation':'Dukascopy June/July and separately Coinexx Jan/Feb/June/July',
       'not_an_exit_or_PnL':True,'train_n':len(inds),'features':FS,'confidence_threshold':threshold,
       'results':results,'elapsed_s':round(time.monotonic()-t,1)}
    out.write_text(json.dumps(receipt,indent=2))
    from joblib import dump
    dump(model,ROOT/'R00_HGB_signal_model.joblib',compress=3)
    print('WROTE',out,flush=True)
if __name__=='__main__':main()
