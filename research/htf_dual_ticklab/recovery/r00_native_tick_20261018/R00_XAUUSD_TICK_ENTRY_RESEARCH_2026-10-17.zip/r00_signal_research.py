"""R00/1: read-only, causal real-tick opportunity signal research.

Original two broker tapes are NEVER merged. All decisions occur at the first
observed tick of each populated 5-second bucket, and all features use only
that quote and earlier quotes or previously COMPLETED higher-timeframe bars.

FUTURE midprice movement at +10s/+30s is used ONLY for retrospective
signal-direction scoring, not as a feature or simulated exit/P&L.

All tuning is exploratory on 2026 Jan/Feb, evaluated chronologically on
June/July 2026 (already historically exposed; not pristine holdout).

Community ideas may inform hypotheses; only SHA-pinned authorized real
bid/ask datasets are accepted as quantitative research inputs.
"""
import argparse, hashlib, json, sys, time
from pathlib import Path
import numpy as np, pandas as pd

REGISTRY={
'XAUUSD_DUKAS_2026_01_ticks.csv.gz':'d2ebb9a8c19caad02c5d95d7c6504868722c286e1187d1dbad18098d8c5ec5c5',
'XAUUSD_DUKAS_2026_02_ticks.csv.gz':'ed3b3545c990c88d78519594c17c8915b0f679adcb0a94920ba7524f1f6d5c5d',
'XAUUSD_DUKAS_2026_06_ticks.csv.gz':'34686ce53ba992dfb83ea35d555b6a4947a9216635853857c8bf11ce70c00ae2',
'XAUUSD_DUKAS_2026_07_ticks.csv.gz':'e171e8c2fb59f3f4147a6f845eb68e664fa9c0f4815caa33acdbb42cc2f768b7',
'XAUUSD_MT5_BROKER_2026_01_ticks_ALL.csv.gz':'1307a75df5d635678de7691908600090a552f38543e0512187dcd7b37fbc66b8',
'XAUUSD_MT5_BROKER_2026_02_ticks_ALL.csv.gz':'5de772aab4d15ebf18aa48850e847c98e2bcb639064790bbed9d87a598c3bf05',
'XAUUSD_MT5_BROKER_2026_06_ticks_ALL.csv.gz':'3033ccb257d067aecc123f3791d9dddc5c95841b9bba167ff1ca0cf1589dc2b4',
'XAUUSD_MT5_BROKER_2026_07_ticks_ALL.csv.gz':'d9d47d40abb33935414edfb5c11f0c518d8c9cc27221da182dab0bc49b0b708d',
}
BASE={'01':27980,'02':33523,'06':31801,'07':25277}
# The recorded Coinexx 2026 offset is empirically approved in Jan/Feb (2h),
# Jun/Jul (3h). March transition and unknown months are OUT OF SCOPE here.

def source_check(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for c in iter(lambda: f.read(4*1024*1024),b''): h.update(c)
    got=h.hexdigest()
    if REGISTRY.get(path.name)!=got: raise ValueError(f'FATAL SOURCE PIN MISMATCH {path.name} {got}')
    return got


def completed_bars(t,mid,unit,bin_type='fixed'):
    # timestamp seconds already shifted to verified UTC
    if bin_type=='fixed': key=t//(unit*1000)
    elif bin_type=='week': key=(t//1000+3*86400)//(7*86400)  # Monday UTC
    else: raise ValueError(bin_type)
    cuts=np.r_[0, np.flatnonzero(np.diff(key))+1]
    out=pd.DataFrame({'key':key[cuts],
        'open':mid[cuts],
        'hi':np.maximum.reduceat(mid,cuts),
        'lo':np.minimum.reduceat(mid,cuts),
        'close':mid[np.r_[cuts[1:]-1,len(mid)-1]],
        'ticks':np.diff(np.r_[cuts,len(mid)])})
    diff=out['close'].diff()
    gain=diff.clip(lower=0).ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    loss=(-diff).clip(lower=0).ewm(alpha=1/14,adjust=False,min_periods=14).mean()
    out['rsi']=100-100/(1+gain/(loss+1e-12))
    prev=out['close'].shift(1)
    tr=np.maximum(out.hi-out.lo,np.maximum((out.hi-prev).abs(),(out.lo-prev).abs()))
    out['atr']=tr.ewm(alpha=1/14,adjust=False,min_periods=14).mean()
    return out


def features(path,out_dir):
    start=time.monotonic()
    digest=source_check(path)
    coin='MT5_BROKER' in path.name
    if coin:
        cols=['time_msc','bid','ask']
        dat=pd.read_csv(path,usecols=cols,dtype={'time_msc':'int64','bid':'float32','ask':'float32'})
        t=dat['time_msc'].to_numpy(dtype=np.int64,copy=False)
        month=path.name.split('2026_')[1][:2]
        t=t-(120 if month in ('01','02') else 180)*60000
        bid=dat['bid'].to_numpy(dtype=np.float32,copy=False)
        ask=dat['ask'].to_numpy(dtype=np.float32,copy=False)
        broker='coinexx'
    else:
        cols=['timestamp_ms_utc','bid_raw','ask_raw']
        dat=pd.read_csv(path,usecols=cols,dtype={'timestamp_ms_utc':'int64','bid_raw':'int32','ask_raw':'int32'})
        t=dat['timestamp_ms_utc'].to_numpy(dtype=np.int64,copy=False)
        bid=dat['bid_raw'].to_numpy(dtype=np.float32,copy=False)*0.001
        ask=dat['ask_raw'].to_numpy(dtype=np.float32,copy=False)*0.001
        broker='dukascopy'
    assert np.all(np.diff(t)>=0), 'timestamps not ordered'
    if np.any(ask<bid) or np.any(bid<=0): raise ValueError('invalid quote')
    mid=((bid.astype(np.float64)+ask.astype(np.float64))*0.5).astype(np.float32)
    del dat,bid,ask
    # First true raw tick in every 5s bucket, without imaginary bars.
    cuts=np.r_[0,np.flatnonzero(np.diff(t//5000))+1]
    now=t[cuts]
    price=mid[cuts]
    # Select historical known-to-exist tick at or BEFORE observation minus offset.
    pts={}
    ages={}
    for s in (5,10,15,30,60,300,900,1800,3600,14400,43200,86400):
        ind=np.searchsorted(t,now-s*1000,side='right')-1
        present=ind>=0
        ages[s]=np.where(present,now-t[np.maximum(ind,0)],10**12)
        pts[s]=np.where(present,mid[np.maximum(ind,0)],np.nan).astype(np.float32)
    # If quote history has a stale gap >15s for micro move, gate it out.
    recent=np.logical_and.reduce([ages[s]<=(s+3)*1000 for s in (5,10,15,30)])
    r={s:price-pts[s] for s in pts}
    travel=np.abs(price-pts[5])+np.abs(pts[5]-pts[10])+np.abs(pts[10]-pts[15])
    eff=np.abs(r[15])/(travel+1e-6)
    # Quote-count-weighted daily VWAP proxy. NEVER a real traded-volume VWAP.
    cum=np.cumsum(mid,dtype=np.float64)
    daykey=t//86400000
    daycuts=np.r_[0,np.flatnonzero(np.diff(daykey))+1]
    di=np.searchsorted(daycuts,cuts,side='right')-1
    dstart=daycuts[di]
    ssum=cum[cuts]-np.where(dstart>0,cum[np.maximum(dstart-1,0)],0)
    av=(ssum/(cuts-dstart+1)).astype(np.float32)
    spread=None
    # Need exact spread at decision: re-read only 2 quote columns for this month's
    # first raw ticks. Temporary second pass, still pinned unchanged bytes.
    if coin:
        q=pd.read_csv(path,usecols=['bid','ask'],dtype='float32')
        spread=(q.ask.to_numpy()[cuts]-q.bid.to_numpy()[cuts]).astype(np.float32)
    else:
        q=pd.read_csv(path,usecols=['bid_raw','ask_raw'],dtype='int32')
        spread=((q.ask_raw.to_numpy()[cuts]-q.bid_raw.to_numpy()[cuts])*0.001).astype(np.float32)
    del q
    df=pd.DataFrame({'utc_ms':now,'price':price,'spread':spread,
            'r5':r[5],'r15':r[15],'r30':r[30], 'r60':r[60],
            'r300':r[300], 'r900':r[900], 'r3600':r[3600],
            'r14400':r[14400], 'r43200':r[43200], 'r86400':r[86400],
            'eff15':eff, 'quote_vwap_delta':price-av,'recent':recent,
            'minute_of_day':(now//60000)%1440})
    # Completed HTF features. Each join requests key current-1, NOT current bar.
    for sec,n in [(5,'s5'),(15,'s15'),(30,'s30'),(60,'m1'),(300,'m5'),(900,'m15'),
                  (1800,'m30'),(3600,'h1'),(14400,'h4'),(43200,'h12'),(86400,'d1')]:
        bars=completed_bars(t,mid,sec)
        keys=bars.key.to_numpy()
        wanted=now//(sec*1000)-1
        j=np.searchsorted(keys,wanted)
        valid=(j<len(keys)) & (keys[np.minimum(j,len(keys)-1)]==wanted)
        at=np.minimum(j,len(keys)-1)
        df[n+'_dir']=np.where(valid,(bars['close'].to_numpy()[at]-bars['open'].to_numpy()[at]),np.nan).astype(np.float32)
        df[n+'_atr']=np.where(valid,bars['atr'].to_numpy()[at],np.nan).astype(np.float32)
        df[n+'_rsi']=np.where(valid,bars['rsi'].to_numpy()[at],np.nan).astype(np.float32)
        if n=='m15':
            lo=bars['lo'].rolling(8,min_periods=8).min().to_numpy()
            hi=bars['hi'].rolling(8,min_periods=8).max().to_numpy()
            fibpos=(price-lo[at])/(hi[at]-lo[at]+1e-6)
            df['fib_pos']=np.where(valid,fibpos,np.nan).astype(np.float32)
    # Higher month/week context: explicitly unavailable at boundaries, not ffilled.
    bars=completed_bars(t,mid,604800,'week')
    w=(now//1000+3*86400)//604800-1
    j=np.searchsorted(bars.key.to_numpy(),w)
    ok=(j<len(bars)) & (bars.key.to_numpy()[np.minimum(j,len(bars)-1)]==w)
    jj=np.minimum(j,len(bars)-1)
    df['w1_dir']=np.where(ok,bars.close.to_numpy()[jj]-bars.open.to_numpy()[jj],np.nan)
    df['month_dir']=np.nan  # no preceding month was loaded (fail closed)
    # First actual tick at/after fixed future observation; invalidate long quote gaps.
    for h in (10,30):
        idx=np.searchsorted(t,now+h*1000,side='left')
        good=idx<len(t)
        ix=np.minimum(idx,len(t)-1)
        good &= (t[ix]-(now+h*1000)<=2000)
        delta=mid[ix]-price
        df['d'+str(h)]=np.where(good,delta,np.nan).astype(np.float32)
    df['broker']=broker
    df['month']=path.name.split('2026_')[1][:2]
    # store frozen features for quick parameter sweeps; lossless tick source retained.
    fout=out_dir/f'R00_{broker}_2026_{df.month.iloc[0]}_5s_events.pkl'
    df.to_pickle(fout)
    receipt={'file':path.name,'source_sha256':digest,'ticks':int(len(t)),
             'decision_buckets':len(cuts),'features_path':str(fout),
             'first_utc_ms':int(t[0]),'last_utc_ms':int(t[-1]),
             'seconds_elapsed':round(time.monotonic()-start,2)}
    (out_dir/(fout.stem+'.json')).write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt),flush=True)
    return df


def qualify(df,min5=.15,eff=.2,spread=.7,regime='adaptive',family='impulse'):
    good=df['recent'].to_numpy()&(df['spread'].to_numpy()<=spread)
    a=df.r5.to_numpy(); b=df.r15.to_numpy(); c=df.r30.to_numpy()
    if family=='impulse':
        direction=np.sign(a)
        valid=(abs(a)>=min5)&(np.sign(a)==np.sign(b))&(abs(b)>=min5*1.5)&(df.eff15.to_numpy()>=eff)
    elif family=='microflip':
        direction=np.sign(a)
        valid=(abs(a)>=min5)&(np.sign(a)!=np.sign(c))&(abs(c)>=min5*1.5)&(df.eff15.to_numpy()>=eff)
    elif family=='vwap_reclaim':
        direction=np.sign(a)
        v=df.quote_vwap_delta.to_numpy()
        valid=(abs(a)>=min5)&(np.sign(a)==np.sign(v))&(abs(v)<np.maximum(df.m5_atr.fillna(0).to_numpy(),1.0)*.7)
    elif family=='fib_reaccel':
        direction=np.sign(a)
        pos=df.fib_pos.to_numpy()
        valid=(abs(a)>=min5)&(np.sign(a)==np.sign(b))&(((pos>=.32)&(pos<=.43))|((pos>=.56)&(pos<=.68)))
    else:raise ValueError(family)
    if regime=='m5atr': valid &= df['m5_atr'].fillna(0).to_numpy()>3.
    if regime=='h1agree': valid &= np.sign(df.h1_dir.fillna(0).to_numpy())==direction
    if regime=='m5agree': valid &= np.sign(df.m5_dir.fillna(0).to_numpy())==direction
    if regime=='m1rsi':
        r=df.m1_rsi.fillna(50).to_numpy()
        valid &= np.where(direction>0,r>50,r<50)
    return good&valid, direction


def evalmask(df,mask,direction,h=10,deadband=.10):
    delta=df['d'+str(h)].to_numpy()
    valid=mask & np.isfinite(delta)
    m=np.flatnonzero(valid)
    if not len(m):return {'signals':0,'accuracy':None,'coverage_pct':0}
    ok=(delta[m]*direction[m])>deadband
    return {'signals':int(len(m)),'accuracy':round(float(np.mean(ok)),5),
            'neutral_pct':round(float(np.mean(abs(delta[m])<=deadband)),5),
            'coverage_pct':round(float(len(m)/len(df)*100),2),
            'long':int(np.sum(direction[m]>0)),'short':int(np.sum(direction[m]<0)),
            'hours':int(np.unique(df.utc_ms.to_numpy()[m]//3600000).size),
            'days':int(np.unique(df.utc_ms.to_numpy()[m]//86400000).size)}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data',default='/mnt/data');ap.add_argument('--out',default='/mnt/data/r00_data');ap.add_argument('--only',default='')
    args=ap.parse_args(); out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    paths=[Path(args.data)/name for name in REGISTRY if (not args.only or args.only in name)]
    for p in paths:
        if not p.exists():raise FileNotFoundError(p)
        features(p,out)
    print('FEATURES_DONE',flush=True)
if __name__=='__main__':main()
