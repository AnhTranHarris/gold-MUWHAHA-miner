"""F334: historical source bid/ask quote counterfactual for trading decisions.
F330 t+5 entry, F332 existing q850 frozen t+15 risk -> optional early EXIT.
Strict original event clock/side/quote index, no future at t15 decision.
Does NOT simulate actual MT5 orders, margin, spreads beyond native bid/ask, fees.
"""
from pathlib import Path
import numpy as np,json,sys,hashlib
ROOT=Path('/mnt/data');HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'f333_mcx01_deferred_quote_economics'))
from f333_deferred_exec_reality import get_source_masks, selected_scores
sys.path.insert(0,str(ROOT/'f323_mcx01_regime_hazard'))
from f295_source_native_build import load_source_native

def at(ts,bid,ask,t,side,clock,latency):
 target=t+clock+latency;ii=np.searchsorted(ts,target,side='left');safe=np.minimum(ii,len(ts)-1)
 valid=(ii<len(ts))&(ts[safe]-target<=1000)
 buy=(side==1);entry=np.where(buy,ask[safe],bid[safe]);close=np.where(buy,bid[safe],ask[safe]);return valid,entry,close

def trial(b,m,latency_ms=0,n_placebo=100):
 masks=get_source_masks(b,m);ids,risk,thr,sha=selected_scores(b,m,masks)
 keep=masks['keep_source_shadow'][ids];t=masks['t'][ids];side=masks['side'][ids];truth=masks['truth'][ids]
 mask=(risk>=thr)&keep
 ts,bid,ask,src_sha,name=load_source_native(b,m)
 v5,en5,_=at(ts,bid,ask,t,side,5000,latency_ms)
 v15,_,out15=at(ts,bid,ask,t,side,15000,latency_ms)
 v30,_,out30=at(ts,bid,ask,t,side,30000,0)
 i30=np.searchsorted(ts,t+30000,side='left');ix=np.minimum(i30,len(ts)-1)
 v30 &= (ts[ix]<t+32000)
 # Source event original +5 and +15 windows strictly ordered; 15 exit must occur before 30 exit.
 valid=keep&v5&v15&v30
 initial=side*(out30-en5);faster=side*(out15-en5)
 gain=faster-initial
 vexit=mask&valid
 baseline=float(np.sum(initial[valid]));policy=baseline+float(np.sum(gain[vexit]))
 selected=int(vexit.sum());positive_count=int(np.count_nonzero(gain[vexit]>0))
 # Same-hour matched-size fixed-count *random* early-exit control among the same source quote-valid parent.
 hour=t//3600000;rng=np.random.default_rng(33401022+int(m)+ (1 if b=='dukascopy' else 0)+latency_ms)
 hours=np.unique(hour[vexit]);groups=[]
 for h in hours:
  eligible=np.flatnonzero(valid&(hour==h));n=int(np.count_nonzero(vexit&(hour==h)))
  if n:groups.append((eligible,n))
 sim=np.zeros(n_placebo,dtype=np.float64)
 for i in range(n_placebo):
  s=0.
  for eligible,n in groups:
   if n>=len(eligible):chosen=eligible
   else:chosen=rng.choice(eligible,size=n,replace=False)
   s+=np.sum(gain[chosen])
  sim[i]=s
 profit_delta=float(np.sum(gain[vexit]));placebo_p=(int(np.count_nonzero(sim>=profit_delta))+1)/(n_placebo+1)
 return {'broker':b,'month':m,'frozen_model_cut':float(thr),'score_sha256':sha,'source_sha256':src_sha,
   'decision_times_ms':[5000,15000,30000], 'latency_ms':latency_ms,'original_late20_historically_exposed':True,
   'total_late20_parent':len(ids),'original_F330_source_kept':int(keep.sum()),'source_bidask_5_15_30_valid':int(valid.sum()),
   'frozen_F332_risk_early_exit_count':selected,'source_correct_early_exits':int(np.count_nonzero(vexit&(truth==0))),
   'source_incorrect_early_exits':int(np.count_nonzero(vexit&(truth!=0))),
   'source_valid_early_exit_improves_price_count':positive_count,
   'baseline_5_to30_bidask_price_edge_sum_usd_per_oz':round(baseline,6),
   'F332_early_exit_price_edge_sum_usd_per_oz':round(policy,6),
   'difference_sum_usd_per_oz':round(profit_delta,6),
   'difference_per_early_exit_usd_per_oz':round(profit_delta/max(1,selected),6),
   'placebo_100_same_hour_mean_delta':round(float(sim.mean()),6),
   'placebo_100_same_hour_sd_delta':round(float(sim.std()),6),
   'placebo_100_same_hour_best_delta':round(float(sim.max()),6),
   'placebo_one_sided_p_lower_bound':placebo_p,
   'real_mt5_executed_pnl':False,'source_only_quote_counterfactual':True}

if __name__=='__main__':
 b,m=sys.argv[1:3];lat=int(sys.argv[3]) if len(sys.argv)>3 else 0
 r=trial(b,m,lat)
 (HERE/f'F334_{b}_{m}_lat{lat}.json').write_text(json.dumps(r,indent=2));print('F334_DONE',json.dumps(r,separators=(',',':')),flush=True)
