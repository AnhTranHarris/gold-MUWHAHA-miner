"""F333 original-source quote counterfactual: F330 5s and F332 15s decisions.
Observations: registered native bid/ask. No MQL5 fills, capital, or live P&L.
Frozen F332 model training-score q850; evaluate FIT-DISJOINT yet HISTORICALLY EXPOSED
late20 on eight original broker-months. Entry first source quote on/after decision
at 5/15s + 0/250/1000ms. Exit first source quote in [t0+30s,t0+32s).
No leakage: current event truth only in post-hoc diagnostics.
"""
import sys,json,hashlib,gc,os
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data');HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'f323_mcx01_regime_hazard'))
from f295_source_native_build import load_source_native
N={'coinexx':{'01':345365,'02':328879,'06':312004,'07':321069},'dukascopy':{'01':344037,'02':324582,'06':297035,'07':301280}}
POL='fit_q850'
LATENCIES=[0,250,1000]
def get_source_masks(b,m):
 f=ROOT/'f330_pending_confirmation'/f'F330_RESEARCH_MASK_tPLUS5_{b}_{m}.npz'
 with np.load(f) as z:
  data={k:z[k].copy() for k in z.files}
 return data

def selected_scores(b,m,source):
 n=len(source['t']);cut=int(.8*n); t_boundary=source['t'][cut]
 dmask=(np.arange(n)>=cut)&(source['t']>=t_boundary+40000)&source['parent']
 folder=ROOT/'f332_mcx01_15s_competing_quote'
 if b=='coinexx':
  f=folder/f'F332_SCORE_model_coinexx_on_coinexx_{m}.npz'
  with np.load(f) as z:
   ix=z['index'];t=z['t'];s=z['side'];y=z['truth'];score=z['score']
  assert np.array_equal(t,source['t'][ix]) and np.array_equal(s,source['side'][ix]) and np.array_equal(y,source['truth'][ix])
  pos=np.searchsorted(ix,np.flatnonzero(dmask));assert np.all(ix[pos]==np.flatnonzero(dmask))
  ids=ix[pos];risk=score[pos]
 else:
  f=folder/f'F332_LATE20_DK{m}_MODEL_dukascopy.npz'
  with np.load(f) as z:ix=z['index'];risk=z['risk'];t=z['t'];s=z['side'];y=z['truth']
  ids=np.flatnonzero(dmask)
  assert np.array_equal(ix,ids) and np.array_equal(t,source['t'][ids]) and np.array_equal(s,source['side'][ids]) and np.array_equal(y,source['truth'][ids])
 thr=json.loads((folder/f'F332_4MONTH_FIT_{b}.json').read_text())['cuts_training_prediction_only'][POL]
 return ids, risk,thr,hashlib.file_digest(open(f,'rb'),'sha256').hexdigest()

def counterfactual_quotes(ts,bid,ask,tt,side,decision_ms,latency_ms):
 """Only original source executable bid/ask quotes. Return prices per t0 event."""
 start=tt+decision_ms+latency_ms; exit_start=tt+30000
 ei=np.searchsorted(ts,start,side='left');xi=np.searchsorted(ts,exit_start,side='left')
 eic=np.minimum(ei,len(ts)-1);xic=np.minimum(xi,len(ts)-1)
 valid=(ei<len(ts))&(xi<len(ts))&(ts[xic]<tt+32000)&(ei<xi)&(ts[eic]-start<=1000)
 en=np.where(side==1,ask[eic],bid[eic]);ex=np.where(side==1,bid[xic],ask[xic]);edge=side*(ex-en)
 edge[~valid]=np.nan
 mid_e=(bid[eic]+ask[eic])/2.;mid_x=(bid[xic]+ask[xic])/2.
 mid_move=side*(mid_x-mid_e)
 mid_move[~valid]=np.nan
 return valid,edge,mid_move,ts[eic]-start,ask[eic]-bid[eic]

def small(arr):
 z=arr[np.isfinite(arr)]
 return {'count':len(z),'mean_usd_per_oz':None if len(z)==0 else round(float(z.mean()),6),
 'sum_usd_per_oz':None if len(z)==0 else round(float(z.sum()),3),
 'positive_fraction':None if len(z)==0 else round(float(np.mean(z>0)),6),
 'median_usd_per_oz':None if len(z)==0 else round(float(np.median(z)),6),
 'after_hypothetical_0p20_per_oz_mean':None if len(z)==0 else round(float(np.mean(z-.2)),6)}

def run_cell(b,m):
 masks=get_source_masks(b,m)
 ids,risk,thr,score_sha=selected_scores(b,m,masks)
 t=masks['t'][ids];side=masks['side'][ids];truth=masks['truth'][ids]
 parent=masks['parent'][ids];keep5=masks['keep_source_shadow'][ids]
 assert np.all(parent) and len(ids)==len(risk)
 veto=risk>=thr
 source_wrong=int(np.count_nonzero(veto&(truth!=0)));source_good=int(np.count_nonzero(veto&(truth==0)))
 compatible=keep5
 incremental_wrong=int(np.count_nonzero(veto&compatible&(truth!=0)))
 incremental_good=int(np.count_nonzero(veto&compatible&(truth==0)))
 ts,bid,ask,sha,name=load_source_native(b,m)
 result=dict(broker=b,month=m,raw_source_file=name,source_sha256=sha,source_ticks=int(len(ts)),fit_disjoint_historically_exposed_late20_events=int(len(ids)),original_F332_q850_wrong_veto=source_wrong,original_F332_q850_correct_lost=source_good,incremental_above_F330_wrong_veto=incremental_wrong,incremental_above_F330_good_loss=incremental_good,
 source_F330_kept=int(keep5.sum()),source_F330_and_F332_kept=int((keep5&~veto).sum()),f332_frozen_cut=thr,score_npz_sha256=score_sha,
 per_latency=[])
 for lag in LATENCIES:
  v5,e5,mid5,g5,sp5=counterfactual_quotes(ts,bid,ask,t,side,5000,lag)
  v15,e15,mid15,g15,sp15=counterfactual_quotes(ts,bid,ask,t,side,15000,lag)
  base=keep5
  kept=keep5&~veto
  removed=keep5&veto
  row={
   'latency_ms':lag,'valid_5s_keep':int(np.count_nonzero(v5&base)),
   'valid_15s_keep':int(np.count_nonzero(v15&base)),
   'valid_15s_kept_after_F332':int(np.count_nonzero(v15&kept)),
   'missing_15s_keep':int(np.count_nonzero(base&~v15)),
   '5s_lookahead_free_quote_edge_F330':small(e5[base]),
   '15s_spread_aware_quote_edge_F330':small(e15[base]),
   '15s_spread_aware_quote_edge_F330_F332':small(e15[kept]),
   '15s_spread_aware_quote_edge_F332_selected_for_veto':small(e15[removed]),
   '15s_paired_waiting_5_to_15_quote_edge':small((e15-e5)[base]),
   '15s_mean_entry_spread_on_valid':float(np.nanmean(sp15[v15&base])) if np.any(v15&base) else None,
   'original_t0_labels_good_selected_for_veto':int(np.count_nonzero(removed&(truth==0)))
  }
  result['per_latency'].append(row)
 del ts,bid,ask
 return result

def main(args):
 b,m=args
 r=run_cell(b,m)
 (HERE/f'F333_{b}_{m}.json').write_text(json.dumps(r,indent=2))
 print(json.dumps({'cell':b+m,'n':r['fit_disjoint_historically_exposed_late20_events'],'selected_bad':r['original_F332_q850_wrong_veto'],'selected_good':r['original_F332_q850_correct_lost'],'incremental_bad':r['incremental_above_F330_wrong_veto'],'incremental_good':r['incremental_above_F330_good_loss'],'edge0':r['per_latency'][0]['15s_spread_aware_quote_edge_F330_F332'],'removed0':r['per_latency'][0]['15s_spread_aware_quote_edge_F332_selected_for_veto']},separators=(',',':')),flush=True)
if __name__=='__main__':main(sys.argv[1:3])
