from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,csv,hashlib,io,os
R=Path('/mnt/data');A=R/'f333_mcx01_deferred_quote_economics';B=R/'f334_mcx01_causal_risk_exit'
BROKERS=('coinexx','dukascopy');MONTHS=('01','02','06','07')
s=[json.loads((A/f'F333_{b}_{m}.json').read_text()) for b in BROKERS for m in MONTHS]
pilot=[json.loads(p.read_text()) for p in B.glob('F334_*_lat0.json')]
assert len(s)==8
assert sum(x['original_F332_q850_wrong_veto'] for x in s)==55950
assert sum(x['original_F332_q850_correct_lost'] for x in s)==4949
out=[]
for x in s:
 r=x['per_latency'][0];out.append(dict(broker=x['broker'],month=x['month'],original_late20_parent=x['fit_disjoint_historically_exposed_late20_events'],source_F332_original_wrong=x['original_F332_q850_wrong_veto'],source_F332_original_correct_lost=x['original_F332_q850_correct_lost'],incremental_over_F330_wrong=x['incremental_above_F330_wrong_veto'],incremental_over_F330_correct_lost=x['incremental_above_F330_good_loss'],native_spread_mean=r['15s_mean_entry_spread_on_valid'],quote_5s_edge=r['5s_lookahead_free_quote_edge_F330']['mean_usd_per_oz'],quote_15s_edge=r['15s_spread_aware_quote_edge_F330_F332']['mean_usd_per_oz'],quote_15s_vetoed_edge=r['15s_spread_aware_quote_edge_F332_selected_for_veto']['mean_usd_per_oz'],paired_waiting_edge=r['15s_paired_waiting_5_to_15_quote_edge']['mean_usd_per_oz']))
with open(A/'F333_8CELL_QUOTE_ECONOMICS.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
agg={}
for q in range(3):
 x=s[0]['per_latency'][q];z={}
 for key in ['5s_lookahead_free_quote_edge_F330','15s_spread_aware_quote_edge_F330','15s_spread_aware_quote_edge_F330_F332','15s_spread_aware_quote_edge_F332_selected_for_veto','15s_paired_waiting_5_to_15_quote_edge']:
  val=[p['per_latency'][q][key] for p in s];n=sum(e['count'] for e in val);z[key]={'n':n,'pooled_usd_oz':sum(e['sum_usd_per_oz'] for e in val)/n}
 agg[str(x['latency_ms'])]=z
summ={'run_id':'F333_F334','research_status':'HISTORICAL_SOURCE_QUOTE_DIAGNOSTICS_ONLY_UNAPPROVED','source_cells':8,'original_late20_F332':{'wrong_veto':sum(e['original_F332_q850_wrong_veto'] for e in s),'correct_lost':sum(e['original_F332_q850_correct_lost'] for e in s)},'incremental_F332_after_F330':{'wrong_veto':sum(e['incremental_above_F330_wrong_veto'] for e in s),'correct_lost':sum(e['incremental_above_F330_good_loss'] for e in s)},'pooled_source_counterfactual':agg,'early_exit_pilot':pilot,'training':'NO NEW TRAINING F332 FOUR_MONTH FITTED QUANTILE FROZEN','source_quotes':'Fresh eight raw original source SHA256 checks per pair; no substituted quotes','caveats':['F332 fitted 4months with early80 and historically exposed late20; pseudoheldback not genuinely unseen','t+15 quote risk cannot be used at t0 or t+5','Bid/ask quote counterfactual is not real MT5 executed fills, gross or net account profit','All 15s quote returns measured to the original t0+30..32 horizon','No exact F17 P05 union, no G01-G09 satisfied','F334 test limited to two pilot broker-months; parked, not expanded because cash-price improvement negative']}
(A/'F333_F334_AGGREGATE_RESULTS.json').write_text(json.dumps(summ,indent=2))
report=f'''# F333–F334 source-native clock and executable-quote research (2026-10-22)

STATUS: RESEARCH-ONLY, NO OWNER APPROVAL, NO FILTER PROMOTION, NO M/G gate. Original owner 17/39 accepted, M-CX-01 OPEN. Reused existing F330 5s mask, F332 15s frozen q850, original source-native Coinexx/Dukascopy Jan/Feb/June/July SHA-pinned tick prices. No engine rebuild or new training; 8 original source-hash checks passed independently per cell.

## Predeclared question
Can the strongest historical five/10/15s abnormal-quote veto meaningfully protect actual executable bid/ask economics? F332 retains same original t0+30..32 truth, but a t+15s decision is a different trading-clock regime. Examine exact same late20 original F234/F330 event IDs under a 5s entry, delayed 15s entry, 0/250/1000ms extra latency, source-native bid/ask first quote, 30..32sec exit reference (not actual order fills). No q selection from outcomes.

## Original immutable teacher/control context
Coinexx Jan same-month hindsight teacher 450tree/255leaf/93 features, q=.250, veto=86,336 incorrect/5 correct; 90% numerical target is ~77,703 incorrectly vetoed in Jan and correct floor, NOT externally verified predictive capability. F234 standalone research baseline 998,996 correct retained, 295,618 bad vetoed across all eight original months; F234+F17 owner historical 998,691/296,457 with final F17 P05 mask unavailable for exact union. F330 F332 unapproved, no additive claims. Original eight month source totals 2,574,251 events, 1,208,071 correct, 1,366,180 wrong/neutral.

## Verified positive event-filter signal and economic countercheck
Original frozen F332 late20 q850 eight cells 55,950 incorrect veto vs 4,949 originally correct lost, 11.305:1. On actual overlapping original F330 retained event masks F332 adds {sum(e['incremental_above_F330_wrong_veto'] for e in s):,} wrong veto /{sum(e['incremental_above_F330_good_loss'] for e in s):,} correct veto = {sum(e['incremental_above_F330_wrong_veto'] for e in s)/sum(e['incremental_above_F330_good_loss'] for e in s):.4f}:1. This is historical 2026 source-exposed, not new predictive success.

At zero additional latency: pooled same-native-source spread-aware hypothetical quote edge, F330 t+5s entry to first native t+30..32s bid/ask exit = {agg['0']['5s_lookahead_free_quote_edge_F330']['pooled_usd_oz']:.6f} USD per oz over {agg['0']['5s_lookahead_free_quote_edge_F330']['n']:,} valid observations; F330 held until t+15 then t+30 = {agg['0']['15s_spread_aware_quote_edge_F330']['pooled_usd_oz']:.6f} USD/oz; F330+F332 surviving t+15 = {agg['0']['15s_spread_aware_quote_edge_F330_F332']['pooled_usd_oz']:.6f} USD/oz. Matched across original event IDs with both prices available, extra 5→15 wait lost {agg['0']['15s_paired_waiting_5_to_15_quote_edge']['pooled_usd_oz']:.6f} USD/oz on average. The negative quote edge is NOT a claim of full EA P&L and does not include lots/margin, commissions, stops, execution probability or overlapping trades. Dukascopy mean native spreads higher in these observed windows; reject any cross-broker universal profitability inference.

## F334 fast-fail causal risk early exit pilot
A distinct action was tested: after a hypothetically entered F330-eligible trade at t+5s, act on the frozen F332 risk score at t+15s as an early CLOSE on the next executable side, otherwise close in original window. Coinexx Jan quote-edge sum worsened by {pilot[0]['difference_sum_usd_per_oz']:.3f} USD/oz across {pilot[0]['frozen_F332_risk_early_exit_count']:,} selected closes; DK July quote-edge sum worsened by {pilot[1]['difference_sum_usd_per_oz']:.3f} USD/oz across {pilot[1]['frozen_F332_risk_early_exit_count']:,}. Same-hour matched exit-count random placebo controls saved. The first exploratory criterion (positive price-edge improvement) failed on both preselected pilot cells; F334 parked without wasting 6 more full raw replay runs. This invalidates this F334 action under the tested clock, not the F332 information signal class.

## Mechanism / new stronger next hypothesis
Original source eight fitted 93D teachers use past/matured class outcomes, quote sign, completed HTF shape, side/multi-horizon direction and future-sample selected quantile to generate artificially near-oracle 86,336/5 Jan. F325 exact teacher vs F234 Jan: teacher-only 74,132 bad/2 good, F234-only 6,382 bad/15,136 good—parallel correct rescue matters. F333/F334 evidence suggests wrong original t0 30s labels can persist despite negative physically executable quote edge at later decision clocks. Next distinct F335 experiment should directly train broker/side/spread/session-conditional **source-executable net edge at t+5 from only t+5-known quote states**; separate selectivity/risk coverage models for correct-direction signals, correct rescue, and relative trade improvement, with 15s quote state ONLY for pending-unfilled orders. Use full 4month label-fitted exploration per owner's >1.5 gate but report contemporaneous fitted and held-back 2026 source-exposed truth separately, test independent broker signed/source quote and 5/15/32s as-of state, placebos, all 4178 source supply windows, and realistic eventual funded shared portfolio 100/200. No March/April/May opened here; any single selection requires clean provenance and no mislabeling old research-exposed data as truly blind.

## Public reproducible logic / community scout
SelectiveNet https://github.com/geifmany/SelectiveNet : joint risk-coverage abstention, not imported model or price data; River ADWIN https://github.com/online-ml/river/blob/main/river/drift/adwin.py : causal broker-quote drift, implement from public logic if chosen; mlfinlab purged CV https://github.com/hudson-and-thames/mlfinlab/blob/master/mlfinlab/cross_validation/cross_validation.py : prevent overlapping 30..32s truth fit/calibration; MQL5 https://www.mql5.com/en/docs/runtime/running and https://www.mql5.com/en/book/applications/timeseries/timeseries_ticks_mqltick : OnTick events may coalesce and CopyTicks recovery is necessary for faithful deployment. Third-party algorithms and price feeds NOT imported into approved repository.

Full original per-cell source SHA, source quote count, correct and wrong class, all original F332 scores hashes, three latencies, mean/median edge, native spread and 100 fixed-seed same-hour F334 placebo outputs in companion JSON and CSV; Python source included. Exact F330/F332 source feature caches/weights and eight original ZIP source quotes are external, referenced pinned dependencies not bundled here. No MetaEditor, no native actual order fill, no investor shared-capital economics, no approval.
'''
(A/'F333_F334_SOURCE_SCIENTIFIC_RECEIPT.md').write_text(report)
# Bundle files with deterministic names, source/source evidence, hashes, no giant raw source duplication.
archive=R/'F333_F334_MCX01_NATIVE_QUOTE_CLOCK_ECONOMICS_RESEARCH_ONLY_20261022.zip'
files=[*A.glob('F333_*.json'),A/'F333_8CELL_QUOTE_ECONOMICS.csv',A/'F333_F334_SOURCE_SCIENTIFIC_RECEIPT.md',A/'f333_deferred_exec_reality.py',A/'f333_f334_finalize.py',*B.glob('F334_*_lat0.json'),B/'f334_causal_exit.py',B/'F334_PREDECLARED_PLAN.json']
files=sorted(set(files),key=lambda q:q.name)
manifest={'experiment':'F333_F334','original_status':'HISTORICAL_RESEARCH_ONLY_UNAPPROVED','files':{}}
with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:
  name=('F333/' if f.parent==A else 'F334/')+f.name
  x=f.read_bytes();z.writestr(name,x);manifest['files'][name]={'sha256':hashlib.sha256(x).hexdigest(),'size':len(x)}
 z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,indent=2))
with ZipFile(archive) as z:
 assert z.testzip() is None
 for name,rec in manifest['files'].items():
  data=z.read(name);assert len(data)==rec['size'] and hashlib.sha256(data).hexdigest()==rec['sha256']
 print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.file_digest(open(archive,'rb'),'sha256').hexdigest(),'members':len(z.namelist()),'manifest_test':'PASS'},indent=2))
