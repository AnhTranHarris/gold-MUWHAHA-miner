"""F327 fixed-policy source-exact Coinexx cooperative arbiter probe, no new models or teacher oracle."""
import json,hashlib,sys
from pathlib import Path
import numpy as np
import lightgbm as lgb
ROOT=Path('/mnt/data'); OUT=Path(__file__).resolve().parent
F324=ROOT/'f324_mcx01_transition_hazard';F326=ROOT/'f326_mcx01_matured_hawkes';F323=ROOT/'f323_mcx01_regime_hazard'
MODEL=F323/'F323_CORRECT_GUARDIAN_coinexx.txt'
MONTHS=('01','02','06','07')

def source_hash(p):
 h=hashlib.sha256();
 with p.open('rb') as f:
  for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
 return h.hexdigest()

def metr(mask,parent,truth):
 assert mask.dtype==np.bool_ and np.all(~mask|parent)
 good=truth==0; bad=~good
 return {'bad_veto':int(np.sum(mask&bad)), 'opposite_veto':int(np.sum(mask&(truth==1))), 'neutral_veto':int(np.sum(mask&(truth==2))),
 'correct_veto':int(np.sum(mask&good)),'wrong_good_ratio':round(int(np.sum(mask&bad))/max(1,int(np.sum(mask&good))),6),
 'correct_remaining':int(np.sum(parent&~mask&good)), 'wrong_rejected_total':int(np.sum(~(parent&~mask)&bad)),
 'correct_retention':round(float(np.sum(parent&~mask&good)/np.sum(good)),7),'wrong_rejection':round(float(np.sum(~(parent&~mask)&bad)/np.sum(bad)),7)}

def run():
 booster=lgb.Booster(model_file=str(MODEL));all_results=[];source=[]
 for m in MONTHS:
  a=F324/f'F324_FROZEN_MASK_coinexx_{m}.npz';b=F326/f'F326_frozen_coinexx_{m}.npz';c=F323/f'F323_CAUSAL_FEATURES_coinexx_{m}.npz'
  with np.load(a) as x,np.load(b) as y,np.load(c) as z:
   for key in ('t','side','truth','parent'):
    assert np.array_equal(x[key],y[key]) and np.array_equal(x[key],z[key]),(m,key,'SOURCE_EVENT_MISMATCH')
   t=x['t'];truth=x['truth'];parent=x['parent'];side=x['side'];va=x['veto'];vb=y['veto'];
   assert not np.any(va&~parent) and not np.any(vb&~parent)
   X=z['X'];assert X.shape==(len(t),124)
   p=booster.predict(X[:,43:83],num_threads=3)
   assert np.isfinite(p).all() and p.min()>=0 and p.max()<=1
   guard=(p<.37)
   arms={'F234_only':np.zeros(len(t),bool),'F324_only':va,'F326_only':vb,'union':va|vb,'agreement':va&vb,
   'protected_union':(va|vb)&guard,'conditional_union':(va&vb)|((va|vb)&guard)}
   row={'broker':'coinexx','month':m,'original_events':len(t),'original_correct':int(np.sum(truth==0)),'original_wrong':int(np.sum(truth!=0)),
        'p_correct_guardian_min':float(p.min()),'p_correct_guardian_max':float(p.max()),'arms':{}}
   for name,mask in arms.items():
    record=metr(mask,parent,truth);record['buy_bad_veto']=int(np.sum(mask&(side==1)&(truth!=0)));record['sell_bad_veto']=int(np.sum(mask&(side==-1)&(truth!=0)));row['arms'][name]=record
   if m=='02':
    boundary=int(len(t)*.60)
    dev=(np.arange(len(t))>=boundary)&(t>=t[boundary]+40000)
    row['feb_late40_screen']={}
    for name,mask in arms.items():
     active=mask&dev
     row['feb_late40_screen'][name]={'bad_veto':int(np.sum(active&(truth!=0))),'correct_veto':int(np.sum(active&(truth==0))),'ratio':round(float(np.sum(active&(truth!=0)))/max(1,int(np.sum(active&(truth==0)))),6)}
   all_results.append(row)
   for kind,fn in [('F324_mask',a),('F326_mask',b),('F323_feature',c)]:source.append({'month':m,'kind':kind,'bytes':fn.stat().st_size,'sha256':source_hash(fn)})
   print('F327_EXACT',m,{k:(v['bad_veto'],v['correct_veto'],v['wrong_good_ratio']) for k,v in row['arms'].items()},flush=True)
  del p,X
 (OUT/'F327_FOURCELL_FACTORS.json').write_text(json.dumps(all_results,indent=2))
 (OUT/'F327_INPUT_HASHES.json').write_text(json.dumps({'guardian':{'sha256':source_hash(MODEL),'bytes':MODEL.stat().st_size},'sources':source},indent=2))
 # No all-4-month aggregate generalization claim. Discovery stratifies chronological/exposed regimes.
 print('F327_COMPLETE_SOURCE_PARITY',len(all_results),flush=True)
if __name__=='__main__':run()
