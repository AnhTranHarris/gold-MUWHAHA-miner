import unittest
import numpy as np
from f327_frozen_arbiter import metr
class F327Controls(unittest.TestCase):
 def test_truth_schema(self):
  t=np.array([0,1,2,0,1,2],dtype=np.int8)
  p=np.array([1,1,1,1,0,0],dtype=bool)
  m=np.array([0,1,1,0,0,0],dtype=bool)
  r=metr(m,p,t)
  self.assertEqual((r['bad_veto'],r['opposite_veto'],r['neutral_veto'],r['correct_veto']),(2,1,1,0))
 def test_parent_subset(self):
  with self.assertRaises(AssertionError):
   metr(np.array([False,True]),np.array([True,False]),np.array([0,1]))
 def test_union_intersection(self):
  a=np.array([1,0,1,0],dtype=bool);b=np.array([1,1,0,0],dtype=bool)
  self.assertEqual((a|b).tolist(),[True,True,True,False])
  self.assertEqual((a&b).tolist(),[True,False,False,False])
 def test_truth_is_evaluation_not_policy(self):
  a=np.array([1,0,1,0],dtype=bool);b=np.array([1,1,0,0],dtype=bool);g=np.array([.2,.99,.2,.5])
  frozen=lambda x,y,z: (x&y)|((x|y)&(z<.37))
  self.assertTrue(np.array_equal(frozen(a,b,g),frozen(a,b,g)))
if __name__=='__main__':unittest.main()
