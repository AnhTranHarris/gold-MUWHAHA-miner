"""F346: F333-owner-approved continuation; independently test predeclared broker/UTC session/side diversity of frozen F337+F344 source vetoes.
No new fitting or target-month threshold adjustment; original eight exposed broker/month cells; no OOS/live validity.
"""
from pathlib import Path
import json,hashlib
import numpy as np
R=Path('/mnt/data');A=R/'f344_f333_conditional_opponent_20261022';F=R/'f335_f333_fourmonth_owner_optimization';O=R/'f346_f333_source_mechanism_audit';O.mkdir(exist_ok=True)
UTC_SESSIONS={'asia':'00:00-07:59 UTC','london':'08:00-12:59 UTC','new_york':'13:00-20:59 UTC','rollover':'21:00-23:59 UTC'}
P={'name':'F346 predeclared diagnostic','data':'original eight months Coinexx/DK Jan/Feb/June/July only','slices':'all broker-months x UTC hour bins Asia[0,8), London[8,13), NY[13,21), Rollover[21,24), source native BUY and SELL','frozen_parent':'F330 t+5000ms','frozen_heads':'F344 independent two head combo q900 pre-calibrated original training only','second_specialist':'F337 R6 frozen already before this readback','selection':'none: all cells/slices disclosed, no session optimizations picked from exposed truth','scopes':'full month including training, late20 purge historically exposed','negative':'report marginal discordance and false veto cost, independent original label; NO financial PNL or G gate','original_trade_clock':'t+15sec PENDING only, cannot replace original instant t0 decision'}
(O/'PREDECLARED.json').write_text(json.dumps(P,indent=2))
rows=[]
for broker in ('coinexx','dukascopy'):
 cut=json.loads((A/f'F344_FIT_{broker}.json').read_text())['thresholds_training_only']['90']
 for month in ('01','02','06','07'):
  with np.load(F/f'F338_MASK_R6_tPLUS15_{broker}_{month}.npz') as z:
   t=z['t'].copy(); side=z['side'].copy(); y=z['truth'].copy(); k=z['f330_keep'].copy();r6=z['f338_incremental_veto'].copy();p=z['parent'].copy()
  with np.load(A/f'F344_SCORE_{broker}_{month}.npz') as z:
   ids=z['index'].copy();score=z['combined_score'].copy();assert np.array_equal(z['t'],t[ids]);assert np.array_equal(z['truth'],y[ids]);assert np.array_equal(z['side'],side[ids]);assert np.array_equal(z['f330_keep'],k[ids]);assert np.all(k[ids])
  q900=np.zeros(len(y),bool);q900[ids]=score>=cut
  assert not np.any(q900&~k) and not np.any(r6&~k)
  utc_hour=((t//3600000)%24).astype('int8')
  sess=np.where(utc_hour<8,'asia',np.where(utc_hour<13,'london',np.where(utc_hour<21,'new_york','rollover')))
  m20=int(.8*len(y));late=(np.arange(len(y))>=m20)&(t>=t[m20]+40000)
  masks={'both':q900&r6,'q900_only':q900&~r6,'r6_only':r6&~q900,'either':q900|r6,'f344_q900':q900,'f337_r6':r6}
  for phase,base in [('full',np.ones(len(y),bool)),('late20',late)]:
   for se in UTC_SESSIONS:
    sm=(sess==se)&base
    for ss in (1,-1):
     us=(side==ss)&sm
     for arm,v in masks.items():
      x=us&v;good=int(np.count_nonzero(x&(y==0)));opp=int(np.count_nonzero(x&(y==1)));neu=int(np.count_nonzero(x&(y==2)));wrong=opp+neu
      rows.append(dict(broker=broker,month=month,phase=phase,session=se,side='BUY' if ss==1 else 'SELL',arm=arm,original_source_count=int(np.count_nonzero(us)),incorrect_veto=wrong,correct_lost=good,opposite=opp,neutral=neu,ratio=round(wrong/max(1,good),4)))
  print('F346',broker,month,'full q900',int(np.sum(q900&(y!=0))),int(np.sum(q900&(y==0))),'r6',int(np.sum(r6&(y!=0))),int(np.sum(r6&(y==0))),flush=True)
meta={'experiment':'F346','status':'source-exposed historical diagnostic ONLY','f333_owner_approved':True,'source_cells':8,'rows_count':len(rows),'sessions':UTC_SESSIONS,'models_frozen':True,'dates_opened':'2026 Jan Feb Jun Jul ONLY','exact_f17_p05_available':False,'source_shadow_not_actual_mt5_trade':True}
summary={}
for phase in ('full','late20'):
 summary[phase]={}
 for arm in ('both','q900_only','r6_only','either','f344_q900','f337_r6'):
  z=[r for r in rows if r['phase']==phase and r['arm']==arm]
  bad=sum(r['incorrect_veto'] for r in z);good=sum(r['correct_lost'] for r in z)
  summary[phase][arm]={'bad':bad,'correct_lost':good,'ratio':round(bad/max(1,good),5)}
meta['summary']=summary
# The following columns are diagnostic only, no fitted thresholds/section policy selected.
for se in UTC_SESSIONS:
 meta.setdefault('by_session',{})[se]={}
 for phase in ('full','late20'):
  meta['by_session'][se][phase]={}
  for arm in ('both','q900_only','r6_only'):
   zz=[r for r in rows if r['session']==se and r['phase']==phase and r['arm']==arm]
   a=sum(r['incorrect_veto'] for r in zz);b=sum(r['correct_lost'] for r in zz)
   meta['by_session'][se][phase][arm]={'bad':a,'good':b,'ratio':round(a/max(1,b),5)}
(O/'F346_8CELL_SOURCE_SESSION_SIDE_ROWS.json').write_text(json.dumps(rows,separators=(',',':')))
(O/'F346_SUMMARY.json').write_text(json.dumps(meta,indent=2))
print('F346_SUMMARY',json.dumps({'summary':summary,'sessions_late20':{s:r['late20'] for s,r in meta['by_session'].items()}}),flush=True)
