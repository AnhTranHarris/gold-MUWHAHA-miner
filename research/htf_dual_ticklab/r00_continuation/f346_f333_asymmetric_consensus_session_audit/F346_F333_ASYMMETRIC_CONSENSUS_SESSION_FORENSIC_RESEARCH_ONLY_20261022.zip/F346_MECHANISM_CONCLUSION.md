# F346 — frozen F333 research follow-on: asymmetric veto mechanism decomposition

Date: 2026-10-22 (research checkpoint; source months January, February, June, July 2026).

**Governance:** Owner explicitly approved F333 original historical native-quote economics research component. Original 39-point checklist remains F01-F17 17/39 historically owner-accepted, M-CX-01 open, G01-G09 open, F337/F344/F345/F346 NOT owner-approved. No MT5 simulation, real order fills, native compilation, investor survival proof, or unseen OOS. April/March/May not accessed. All here is four-month fitted and historically-exposed late20 diagnostic on immutable source-event 30-32sec three-class labels. F332/F344 late t+15 signal acts only for **pending** unfilled candidates. F330 parent at t+5 held fixed. Two brokers, four source months, fixed corrected UTC.

## Frozen cooperative source mechanism — independently recounted using exact original event-level arrays

| Frozen arm | All eight full fitted/previously exposed months wrong veto | Full correct sacrificed | Full wrong:good | Eight late20 wrong veto | Late20 correct lost | Late20 ratio |
|---|---:|---:|---:|---:|---:|---:|
| F337 R6 AND F344 q900 | 141,822 | 6,939 | 20.438:1 | 27,055 | 1,575 | 17.178:1 |
| F344 q900 ONLY (not R6) | 42,747 | 4,819 | 8.871:1 | 8,502 | 938 | 9.064:1 |
| F337 R6 ONLY (not F344) | 23,373 | 2,040 | 11.457:1 | 4,026 | 451 | 8.927:1 |
| Union | 207,942 | 13,798 | 15.070:1 | 39,583 | 2,964 | 13.355:1 |

*Positive discovery:* the **independently agreeing veto regime** is measurably higher-purity than either unilateral disagreement: it accounts for 141,822 original incorrect rejected at 6,939 correct lost on the entire historical eight-cell population. In historically exposed but model-fit-disjoint late20, consensus preserves 17.18:1 wrong/good. Both experts disagree with much worse ~9:1 late20 marginal selectivity. This supports **context-dependent consensus with abstention**, not more additive expert veto thresholds. The consensus alone misses owner's >300k gross objective.

Source-native predeclared UTC sessions from immutable normalized UTC event t: Asia 00-07, London 08-12, New York 13-20, rollover 21-23. Under frozen F337 AND F344 q900 on historically exposed late20, wrong/good ratio respectively **15.865, 17.243, 19.342, 14.544**. All session/side/broker/month results are fully retained in JSON; do NOT train/select a single session after inspecting the same source truth and claim OOS.

## New engineering mechanisms to test (NOT TRAINED/APPROVED)

1. **F347 independent *as-of five-second* executable-opportunity specialist** that predicts unfavorable trade economics using source-native direction-correct bid/ask spread/age/path and quote-revision types, qualified by broker, session, recent completed M15/H1 structure. This is distinct information from F332's 15sec original-label-derived posterior and must be causal at the decision clock. Evaluate executable price fills/commission/margin, not only same-origin directional event label.
2. **F348 residual opponent and neutral architecture with targeted disagreement coverage:** train a genuinely independent information head only over historically frozen high-margin q900-only and R6-only disagreements; exploit proved cooperative consistency and prohibit 15sec post-entry veto. Disagreement margin full=66,120 bad for 6,859 right: increasing volume by naive union spends correct budget too quickly. Evaluate per broker/month, false veto error, source supply and fit-disjoint stress; no teacher target-month label as decision feature.
3. **F349 price-edge-aware risk/coverage** with 4-way state keep, cancel pending, recover F234-rejected correct candidates, or abstain. Model class imbalance separately for opponent and neutral outcomes while enforcing original correct-retention and R9 source windows. Use prospective independent post-exposure data for genuine final validation after owner authorizes exact one blind month or fresh forward stream.

The simultaneous owner constraint >300k gross incorrect veto and <10k gross correct sacrificed requires >30:1 total selectivity, much stronger than the standalone >12:1. **No current frozen policy has achieved this.** F341 q800 is historically positive NET +310,073 wrong and NET +35,765 correct SAVED vs F330 through disjoint-origin F331 recovery, but gross 334,622 wrong /37,091 correct fails owner's gross loss limit and DK July late20 <71% correct retained. Never merge independent component impact with final accepted F17 P05 without its exact original mask.

Public reproducible mechanisms inspiration: SelectiveNet https://github.com/geifmany/selectivenet and original methodology https://proceedings.mlr.press/v97/geifman19a.html; MQL5 true tick replay `CopyTicksRange` https://www.mql5.com/en/docs/series/copyticksrange; OnTick coalesced event caveat https://www.mql5.com/en/docs/series/copyticks. No external tick datasets/models imported. Research engine baseline ca4b58aec597174b6f6d18ab2f36cba6836e4f4c unchanged, no ENGINE_DEFECT_TICKET.

Output: exact script + predeclared policy + 768 rows (eight months × two splits × four UTC sessions × two sides × six arms) + full mechanistic conclusion, ZIP hash manifest and CRC. Full F344 two-head trained models in independently verified archived original `F333_F344_F345_FOURMONTH_OPPONENT_TRAINED_MODELS_RESEARCH_ONLY_20261022.zip` SHA256 `8841070b1d2ef480fafdaba87380b541eae2da92ab8169703682ab5ba7f2b765`, do not duplicate it in small F346 audit archive. No full original gzip tapes are redistributed.
