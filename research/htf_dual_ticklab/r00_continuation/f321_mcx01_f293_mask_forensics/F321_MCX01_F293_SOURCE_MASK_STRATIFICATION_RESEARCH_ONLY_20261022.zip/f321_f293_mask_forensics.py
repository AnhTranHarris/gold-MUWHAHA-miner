"""F321: source-exact F293 historical-mask distribution audit, NOT a predictor.

Only original archived 8 event masks, original F234 parent masks and verified
source-neutral UTC event timestamps. Label 0=correct, 1=opposite, 2=neutral.
This retrospective audit NEVER uses historical labels or F293 scores as live features.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import re
from pathlib import Path
from zipfile import ZipFile
import numpy as np

EXPECTED_RECOVERY_SHA256 = "00a63974729667568297ed1aa713f8d102929cf393e57e8c3509cb4d8ca94397"
EXPECTED_COUNTS = (2_574_251, 1_208_071, 1_064_545, 301_635)
EXPECTED_F293 = (134_801, 3_957)
CELL_RE = re.compile(r"^F293_MASK_(coinexx|dukascopy)_(01|02|06|07)_F234_PARENT_UNAPPROVED\.npz$")


def sha256(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def validate_cell(d: dict[str, np.ndarray]) -> None:
    names = {"t", "truth", "side", "parent", "veto", "keep", "score"}
    if set(d) != names:
        raise ValueError(f"Unexpected fields: {set(d) ^ names}")
    n = len(d['t'])
    if any(len(v) != n for v in d.values()):
        raise ValueError('Length mismatch')
    if not np.all(d['t'][1:] >= d['t'][:-1]):
        raise ValueError('Non-monotonic original event timeline')
    if not np.all(np.isin(d['truth'], [0, 1, 2])):
        raise ValueError('Expected original truth values 0/1/2')
    if not np.all(np.isin(d['side'], [-1, 1])):
        raise ValueError('Unexpected original BUY/SELL sides')
    if np.any(d['veto'] & ~d['parent']):
        raise ValueError('F293 veto outside F234 parent')
    if not np.array_equal(d['keep'], d['parent'] & ~d['veto']):
        raise ValueError('F293 keep inconsistent with original parent and veto')


def aggregate_cell(d: dict[str, np.ndarray], broker: str, month: str):
    validate_cell(d)
    correct = d['truth'] == 0
    bad = ~correct
    hour = ((d['t'] // 3_600_000) % 24).astype(np.int32)  # t already normalized UTC
    side_code = (d['side'] == 1).astype(np.int32)
    groups = 24 * side_code + hour
    base = {"broker": broker, "month": month}
    detail = []
    for k in range(48):
        m = groups == k
        parent = d['parent'] & m
        veto = d['veto'] & m
        pgood = int((parent & correct).sum())
        pbad = int((parent & bad).sum())
        goodloss = int((veto & correct).sum())
        wrongveto = int((veto & bad).sum())
        detail.append({**base,"utc_hour":int(k%24),"original_side":"BUY" if k//24 else "SELL",
                      "parent_correct":pgood,"parent_wrong":pbad,
                      "incremental_wrong_veto":wrongveto,"incremental_correct_loss":goodloss,
                      "bad_veto_coverage":round(wrongveto/pbad,9) if pbad else None,
                      "correct_loss_rate":round(goodloss/pgood,9) if pgood else None})
    summary = {**base,"events":len(d['truth']),
               "correct":int(correct.sum()),"opposite":int((d['truth']==1).sum()),
               "neutral":int((d['truth']==2).sum()),
               "f234_parent":int(d['parent'].sum()),
               "bad_veto":int((d['veto'] & bad).sum()),
               "correct_loss":int((d['veto'] & correct).sum()),
               "veto_opposite":int((d['veto'] & (d['truth']==1)).sum()),
               "veto_neutral":int((d['veto'] & (d['truth']==2)).sum())}
    assert sum(r['incremental_wrong_veto'] for r in detail) == summary['bad_veto']
    assert sum(r['incremental_correct_loss'] for r in detail) == summary['correct_loss']
    return summary, detail


def audit(archive: Path, destination: Path):
    if digest_file(archive) != EXPECTED_RECOVERY_SHA256:
        raise ValueError('Outer source archive SHA256 mismatch')
    seen=set(); summaries=[]; details=[]
    with ZipFile(archive) as outer:
        if outer.testzip() is not None: raise ValueError('Outer ZIP CRC mismatch')
        for subpath in sorted(n for n in outer.namelist() if '/F293_EXACT_MASKS_' in n and n.endswith('.zip')):
            with ZipFile(io.BytesIO(outer.read(subpath))) as z:
                if z.testzip() is not None: raise ValueError('Inner ZIP CRC mismatch')
                manifest=json.loads(z.read('MEMBER_SHA256_MANIFEST.json'))
                for row in manifest:
                    raw=z.read(row['path'])
                    if sha256(raw)!=row['sha256'] or len(raw)!=row['bytes']:
                        raise ValueError('Original mask member hash or size mismatch: '+row['path'])
                    match=CELL_RE.fullmatch(row['path'])
                    if not match:raise ValueError('Unknown original mask: '+row['path'])
                    broker,month=match.groups(); key=(broker,month)
                    if key in seen:raise ValueError('Duplicate broker-month')
                    seen.add(key)
                    with np.load(io.BytesIO(raw),allow_pickle=False) as arr:
                        d={k:arr[k] for k in arr.files}
                    summary,detail=aggregate_cell(d,broker,month)
                    summaries.append(summary);details.extend(detail)
    if len(seen)!=8:raise ValueError('Missing original source cells')
    totals=[sum(r[k] for r in summaries) for k in ('events','correct','opposite','neutral')]
    if tuple(totals)!=EXPECTED_COUNTS:raise ValueError(f'Immutable source population mismatch: {totals}')
    bad=sum(r['bad_veto'] for r in summaries)
    good=sum(r['correct_loss'] for r in summaries)
    if (bad,good)!=EXPECTED_F293:raise ValueError(f'Original accepted F293 receipt mismatch: {bad}/{good}')
    destination.mkdir(parents=True,exist_ok=True)
    with (destination/'f321_original_8cell_summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summaries[0]));writer.writeheader();writer.writerows(summaries)
    with (destination/'f321_utc_hour_side_8cell.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(details[0]));writer.writeheader();writer.writerows(details)
    result={"kind":"SOURCE_EXACT_HISTORICAL_MASK_FORENSICS_NOT_PREDICTIVE",
            "source_archive_sha256":EXPECTED_RECOVERY_SHA256,"label_semantics":{"0":"correct","1":"opposite","2":"neutral"},
            "normalized_utc_timestamp_in_original_t":True,"f293_parent":"F234_ONLY",
            "total_events":totals[0],"original_correct":totals[1],"original_opposite":totals[2],"original_neutral":totals[3],
            "additional_incorrect_veto":bad,"additional_correct_loss":good,"historical_selectivity":bad/good,
            "cells":summaries,"limitations":["F293 trained/scored same four study months: no unseen predictive evidence",
               "UTC-hour and BUY/SELL are retrospective strata, NOT validated features or trade sessions",
               "Cannot combine with approved F17 without its original P05 exact event masks",
               "Not an M-CX-01 candidate model; no quota, MQL5, fill, or profit claim"]}
    (destination/'f321_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    return result,details

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();s,_=audit(a.archive,a.out)
    print(json.dumps({k:s[k] for k in ('total_events','additional_incorrect_veto','additional_correct_loss','historical_selectivity')},indent=2))
