# F321 — M-CX-01 historical F293 source-mask stratification

2026-10-22 | **RESEARCH-HISTORICAL ONLY / NO NEW PREDICTOR / NO OWNER APPROVAL**

## Source and claim boundaries

This is a new, bounded diagnostic of ORIGINAL preserved F293 four-month in-sample fitted event masks. It is not a new fitted or causally transfer-validated M-CX-01 replacement. Preserve the original 17/39 historical-approved checklist; M-CX-01 and G01–G09 remain OPEN. The accepted F17 P05 original mask is still unavailable; the F17 shadow is NOT used here. No F293 mask was added to the F17 totals.

Exact source: MT5_EXPAND verified 42,392,551-byte recovery archive, SHA256 `00a63974729667568297ed1aa713f8d102929cf393e57e8c3509cb4d8ca94397`; embedded Coinexx and Dukascopy original four-month F293 masks. Outer ZIP CRC, two embedded ZIP CRC tests, all eight original NPZ member sizes/hashes, identity invariants, immutable original source-denominator totals and original F293 veto aggregate verified.

Labels: `truth==0` = originally correct; `truth==1` = opposite; `truth==2` = neutral. Original `t` is already normalized UTC in source mask. BUY `side==+1`, SELL `side==-1`; `veto => F234_parent`, `keep == F234_parent && !veto` verified for every event. No raw Coinexx wallclock recorrection is applied to this already-normalized `t`.

Original population recovered exactly: 2,574,251 events = 1,208,071 correct + 1,064,545 opposite + 301,635 neutral. Verified F293 incremental vs immutable F234 parent: 134,801 wrong/neutral vetoed and 3,957 correct vetoed (historical same-sample selectivity 34.06646:1). The results REPRODUCE an existing retrospective F293 finding, not unseen performance.

## New stratification evidence — original January ONLY

| January | Parent-eligible wrong (BUY / SELL) | F293 wrong veto (BUY / SELL) | F293 correct lost (BUY / SELL) | Parent-wrong veto rate (BUY / SELL) |
|---|---:|---:|---:|---:|
| Coinexx | 88,255 / 56,655 | 8,180 / 3,229 | 128 / 49 | 9.27% / 5.70% |
| Dukascopy | 74,286 / 46,354 | 6,380 / 2,971 | 106 / 59 | 8.59% / 6.41% |

January F293's fitted wrong vetoes therefore tilt toward BUY-side examples at both brokers. This is a **descriptive feature-selection hypothesis**, not evidence that buying or selling, or any clock hour, is predictive of profitable outcomes. Event eligibility, raw quote revision frequency, and the in-sample F293 fitting process may confound this asymmetry. Detailed complete original eight broker-month × 24 UTC hours × two sides counts are saved in `f321_utc_hour_side_8cell.csv` to prevent anecdotal cherry-picking.

No new strategy score was fitted or calibrated, no thresholds selected for trade entry, and no protected-correct rescue was activated. Nothing here establishes the original January 86,336 incorrect/5 correct fitted teacher parity. We have not reused a F315–F320 failed score grid or fabricated a real-tick predictive experiment.

## Next legitimately distinct mechanism candidate (NOT executed)

Predeclare a **side-conditional source-native bid-revision/ask-revision reversal state machine, gated by completed HTF M15/H1 structural phase, spread/age states and strictly matured past event histories**. Fuse opposite and neutral risk using a protected-correct arbiter. Unlike F318–F320 frozen percentile score grids, the hypothesis focuses on transport of a quote-transition *state* and a regime-conditioned abstention action, not relabeling F293 fitted masks or adjusting scores toward observed labels. Fit on Jan + early Feb with a 33-second decision-outcome purge, freeze against Feb last40, measure exposed June/July separately, classwise and exact event-ID matched to unchanged F234; require per-cell original ≥71% correct retention, ≥90% bad rejection and original 4,178 source R9 quota rows for integrated claims. Owner approval is required before authorizing any untouched prospective month (April reserved). Clear fast-fail: if no predeclared policy achieves meaningful held-out wrong/good selectivity and correct protection, park the family rather than search adjacent percentile grids.

M-CX-01 original exact acceptance definition: Coinexx January original 450-tree/255-leaf 93-feature fitted teacher, 345,365 event IDs, 181,869 original correct, selected binary q=.250 originally removed 86,336 wrong at 5 correct losses, all fitted/scored same January. Causal function portfolio with equivalent monthly mask quality still OPEN; new numerical event masks and separately verified MQL5 parity required for eventual approval. Retrospective teacher outcomes cannot become live input features.

## Delivery / limitations

Source reader available: F293 original eight NPZ event masks in verified MT5_EXPAND kit. Missing/not used: untouched original F17 P05 final mask; F318-F320 original full 104 MB research ZIP is not verified in Drive/GitHub/current container; full raw tick data not re-downloaded for this bounded forensic, and no native EA backtest was run. F295 January/February derived cache byte parity discrepancy remains unresolved only when exact derived feature parity is required. No change to research engines or legacy source. No new EA integration claim, fills, profits, cost, or $100/$200 survival evidence. This is *source-exact historical-mask forensic reproduction with new stratification*, not a positive predictive discovery.

Reproduce: Python `numpy` standard library, run `python -m unittest test_f321 -v`, then `python f321_f293_mask_forensics.py --archive <verified recovery ZIP> --out .`. All eight NPZ source-member hashes and event invariants are checked. Reproducible output includes `f321_original_8cell_summary.csv`, `f321_utc_hour_side_8cell.csv` and `f321_receipt.json`.
