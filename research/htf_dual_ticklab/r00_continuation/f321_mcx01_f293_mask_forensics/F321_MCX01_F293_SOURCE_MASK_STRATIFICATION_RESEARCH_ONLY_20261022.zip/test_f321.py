import unittest
import numpy as np
from f321_f293_mask_forensics import aggregate_cell,validate_cell

class TestF321(unittest.TestCase):
    def toy(self):
        return dict(t=np.array([3600000,3600001,7200000]),
                    truth=np.array([0,1,2],dtype=np.int8),side=np.array([1,1,-1],dtype=np.int8),
                    parent=np.array([True,True,False]),
                    veto=np.array([False,True,False]),keep=np.array([True,False,False]),
                    score=np.zeros(3,dtype=np.float32))
    def test_truth_encoding(self):
        s,rows=aggregate_cell(self.toy(),'coinexx','01')
        self.assertEqual((s['correct'],s['opposite'],s['neutral']), (1,1,1))
        self.assertEqual((s['bad_veto'],s['correct_loss']), (1,0))
        self.assertEqual(next(r for r in rows if r['utc_hour']==1 and r['original_side']=='BUY')['incremental_wrong_veto'],1)
    def test_reject_out_of_parent(self):
        d=self.toy();d['veto'][2]=True
        with self.assertRaises(ValueError):validate_cell(d)
    def test_reject_reverse_timeline(self):
        d=self.toy();d['t']=d['t'][::-1]
        with self.assertRaises(ValueError):validate_cell(d)
    def test_reject_keep_mismatch(self):
        d=self.toy();d['keep'][1]=True
        with self.assertRaises(ValueError):validate_cell(d)
if __name__=='__main__':unittest.main()
